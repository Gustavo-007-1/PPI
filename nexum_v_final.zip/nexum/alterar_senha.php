<?php 
    session_start();
    if (empty($_SESSION)) {
        header('Location: ../index.php');
        exit();
    }

?>
<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Nexum</title>
        <link rel="stylesheet" href="./assets/aletrar_senha.css">
        <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
        <link rel="stylesheet" href="./assets/linha_branca_cima.css">
        <link rel="stylesheet" href="./assets/imagens/if.png">
        
    </head>
    <body>
    
    <div class="linha_branca_cima">
        <img class='logo_if' src="./assets/imagens/if.png" alt="Logo IF">
        <a class="titulo_nexum" href="./pagina_principal.php">Nexum</a>
        <?php 
            
        ?>

        <div>

        <div class="expansao" onclick="toggleMenu()">
            <i class="bi bi-list"></i>
        </div>

        <div class="menu_lateral">
            <ul>
            <li class="item_menu" id="item_menu">
                <?php 
                   
                    if($_SESSION["categoria"]==1){
                        echo "<a href=\"./gerenciar_usuario\">Gerenciar Usuarios</a>";
                    }
                    if(($_SESSION["categoria"]==1) || ($_SESSION["categoria"] == 2)){
                        echo "<a href=\"./gerenciar_disciplina\">Gerenciar Disciplinas</a>";
                        echo "<a href=\"./gerenciar_parecer\">Pareceres</a>";
                    }
                    echo "<a href=\"./curso_turma\">Cursos e Turmas</a>";
                    echo "<a href=\"./gerenciar_data\">Eventos</a>";
                    echo "<a href=\"./relatorio_atividade\">Relatórios de Atividades</a>";
                    echo "<a href=\"./plano_trabalho\">Plano de Trabalho</a>";
                    echo "<a class='botao_alterar_senha' href=\"./alterar_senha.php\">Alterar Senha</a>";
                    echo "<a class='botao_sair' href=\"./logout.php\">Sair</a>";
                ?>
                </div>
            </li>
            </ul>
        </div>

        <script>
            // Função para alternar a visibilidade do menu
            function toggleMenu() {
            const menuLateral = document.querySelector('.menu_lateral');
            const content = document.querySelector('.content');
            menuLateral.classList.toggle('expandido');
            content.classList.toggle('expandido');
            }
        </script>

        </div>
    </div>




        <div class='titulo_aletrar_senha'>Alterar Senha</div>

    <div class="quadrado_branco_aletrar">

            <form action="./pagina_principal.php?page=alterar" method="POST">
                <div>
                <br>
                    <label class='parte_letra'>Senha Atual</label> <br>
                    <input type="password" name="senha_atual"> <br> <br>
                <div>
                    <label class='parte_letra'>Nova Senha</label> <br>
                    <input type="password" name="senha_nova"> <br> <br>
                </div>
                <div>
                    <label class='parte_letra'>Confirmar a Nova Senha</label> <br>
                    <input type="password" name="senha_confirmar"> <br> <br>
                </div>
                <div>
                    <button class='botao_confirmar' type="submit">Enviar</button> <br> <br>
                </div>
            </form>

    </div>

    </body>
</html>