<?php 
    session_start();
    if (empty($_SESSION)) {
        header('Location: ./index.php');
        exit();
    }

    switch (@$_REQUEST["page"]){
        case 'usuario':
            header('Location: ./gerenciar_usuario/index.php');
            exit();
            break;
        
        case 'gerenciar_disciplina':
            header('Location: ./gerenciar_disciplina/index.php');
            exit();
            break;

        case 'principal':
            header('Location: ./pagina_principal.php');
            exit();
            break;
        
        case 'parecer':
            header('Location: ./gerenciar_parecer/index.php');
            exit();
            break;

        case 'curso_turma':
            header('Location: ./curso_turma/index.php');
            exit();
            break;
        
        case 'alterar_senha':
            header('Location: ./alterar_senha.php');
            exit();
            break;

        case 'alterar':
            header('Location: ./alterar.php');
            exit();
            break;
        
        case 'evento':
            header('Location: ./gerenciar_data/index.php');
            exit();
            break;
        
        case 'relatorio_atividade':
            header('Location: ./relatorio_atividade/index.php');
            exit();
            break;
        
        case 'plano_trabalho':
            header('Location: ./plano_trabalho/index.php');
            exit();
            break;

        case 'logout':
            header('Location: ./logout.php');
            exit();
            break;

        default:
            break;
    }
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Nexum</title>

    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
    <link rel="stylesheet" href="./assets/pag_principal.css">
    <link rel="stylesheet" href="./assets/pag_principal2.css">
    <link rel="stylesheet" href="./assets/linha_branca_cima.css">
    <link rel="stylesheet" href="./assets/imagens/if.png">
    <link rel="stylesheet" href="./assets/titulos_padronizados.css">
</head>
<body>

    


    <div class="linha_branca_cima">
        <img class='logo_if' src="./assets/imagens/if.png" alt="Logo IF">
        <a class="titulo_nexum" href="?page=principal">Nexum</a>
        <?php 
            
        ?>

        <div>

        <div class="expansao" onclick="toggleMenu()">
            <i class="bi bi-list"></i>
        </div>

        <div class="menu_lateral">
            <ul>
            <li class="item_menu" id="item_menu">
                <?php 
                   
                    if($_SESSION["categoria"]==1){
                        echo "<a href=\"?page=usuario\">Gerenciar Usuarios</a>";
                    }
                    if(($_SESSION["categoria"]==1) || ($_SESSION["categoria"] == 2)){
                        echo "<a href=\"?page=gerenciar_disciplina\">Gerenciar Disciplinas</a>";
                        echo "<a href=\"?page=parecer\">Pareceres</a>";
                    }
                    echo "<a href=\"?page=curso_turma\">Cursos e Turmas</a>";
                    echo "<a href=\"?page=evento\">Eventos</a>";
                    echo "<a href=\"?page=relatorio_atividade\">Relatórios de Atividades</a>";
                    echo "<a href=\"?page=plano_trabalho\">Plano de Trabalho</a>";
                    echo "<a class='botao_alterar_senha' href=\"?page=alterar_senha\">Alterar Senha</a>";
                    echo "<a class='botao_sair' href=\"?page=logout\">Sair</a>";
                ?>
                </div>
            </li>
            </ul>
        </div>

        <script>
            // Função para alternar a visibilidade do menu
            function toggleMenu() {
            const menuLateral = document.querySelector('.menu_lateral');
            const content = document.querySelector('.content');
            menuLateral.classList.toggle('expandido');
            content.classList.toggle('expandido');
            }
        </script>

        </div>
    </div>

    <div class="tirulo_nexum">Nexum</div>

    <div class="container_invisivel">

        <div class="quadrado_branco">
            <div class="texto_previa">Oque é o Nexum? <i class="bi bi-chevron-double-down"></i></div>
            O Nexum é um sistema Web desenvolvido para facilitar o gerenciame﻿nto das informações dos estudantes do ensino médio técnico integrado, ele é destinado para os professores e coordenação do IFFAR. O sistema foi desenvolvido para reunir de forma automática e eficiente todas as informações dos estudantes em um único lugar para conselhos de classe, pareceres e demais consultas.
        </div>
        

        <div class="quadrado_branco_equipe">

            <div class="texto_previa">Conheça nossa equipe <i class="bi bi-chevron-double-down"></i></div> <br> <br>

            <span class='nome'>- Felipe Cauduro Barro</span> Lean inception; Desenvolvimento do artigo, slides e documento de requisitos; Parte dos protótipos de tela; <br> <br>

            <span class='nome'>- Gustavo Ariel Koppe</span> Lean Inception; Revisão do código; Requisitos de Sistema; Diagrama de Atividades; Diagrama de Casos de Uso; Programação front-End; Revisão do documento de requisitos e modelos de sistema; <br> <br>

            <span class='nome'>-  João Felipe Hermes Gemelli </span> Lean inception; requisitos do sistema; Protótipos de tela; Artigo; <br> <br>

            <span class='nome'>- Patrícia Freo Stanga</span> Lean Inception; Requisitos de Sistema; Banco de Dados; Diagrama de Atividades; Diagrama de Casos de Uso; Programação Back-End; Revisão de artigo, documento de requisitos, modelos de sistema e slides;

        </div>

        <div class="quadrado_branco">
            <div class="texto_previa">Documentação <i class="bi bi-chevron-double-down"></i></div>
        </div>




    </div>



    
</body>
</html>
