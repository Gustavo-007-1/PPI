

<div class="quadado_branco_editar">
<div class='titulo_editar'>Cadastrar Evento</div> <br>


<form action="?page=salvar&acao=cadastrar" method="POST">
    <div>
        <label class='parte_texto'>Nome</label> <br>
        <input type="text" name="nome" required> <br> <br>
    </div>
    <div>
        <label class='parte_texto'>Data</label> <br>
        <input type="date" name="data" required> <br> <br>
    </div>
    <div>
        <label class='parte_texto'>Descrição<br></label>
        <textarea name="descricao" required></textarea> <br> <br>
    </div>
    <div>
        <button class='botao_salvar' type="submit">Adicionar</button>

    </div>
</form>

</div>