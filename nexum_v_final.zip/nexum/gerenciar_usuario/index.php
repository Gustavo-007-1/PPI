<?php 
    session_start();
    if (empty($_SESSION)) {
        header('Location: ../index.php');
        exit();
    }

?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Nexum</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
    
    <link rel="stylesheet" href="../assets/imagens/if.png">
    <link rel="stylesheet" href="../assets/titulos_padronizados.css">
    <link rel="stylesheet" href="../assets/gerenciar_usuarios.css">
    <link rel="stylesheet" href="../assets/linha_branca_cima.css">
</head>
<body>
    
    <div class="linha_branca_cima">
        <img class='logo_if' src="../assets/imagens/if.png" alt="Logo IF">
        <a class="titulo_nexum" href="?page=principal">Nexum</a>
        <?php 
            
        ?>

        <div>

        <div class="expansao" onclick="toggleMenu()">
            <i class="bi bi-list"></i>
        </div>

        <div class="menu_lateral">
            <ul>
            <li class="item_menu" id="item_menu">
                <?php 
                   
                    if($_SESSION["categoria"]==1){
                        echo "<a href=\"?page=usuario\">Gerenciar Usuarios</a>";
                    }
                    if(($_SESSION["categoria"]==1) || ($_SESSION["categoria"] == 2)){
                        echo "<a href=\"?page=gerenciar_disciplina\">Gerenciar Disciplinas</a>";
                        echo "<a href=\"?page=parecer\">Pareceres</a>";
                    }
                    echo "<a href=\"?page=curso_turma\">Cursos e Turmas</a>";
                    echo "<a href=\"?page=evento\">Eventos</a>";
                    echo "<a href=\"?page=relatorio_atividade\">Relatórios de Atividades</a>";
                    echo "<a href=\"?page=plano_trabalho\">Plano de Trabalho</a>";
                    echo "<a class='botao_alterar_senha' href=\"../alterar_senha.php\">Alterar Senha</a>";
                    echo "<a class='botao_sair' href=\"?page=logout\">Sair</a>";
                ?>
                </div>
            </li>
            </ul>
        </div>

        <script>
            // Função para alternar a visibilidade do menu
            function toggleMenu() {
            const menuLateral = document.querySelector('.menu_lateral');
            const content = document.querySelector('.content');
            menuLateral.classList.toggle('expandido');
            content.classList.toggle('expandido');
            }
        </script>

        </div>
    </div>

    
    <div>
        <?php 
            include "../config.php";
            switch (@$_REQUEST["page"]){
                
                case 'cadastrar':
                    include("./cadastrar.php");
                    break;

                case 'editar':
                    include("./editar.php");
                    break;

                case 'salvar':
                    include("./salvar.php");
                    break;
                
                case 'logout':
                    header('Location: ../logout.php');
                    exit();
                    break;
                
                case 'principal':
                    header('Location: ../pagina_principal.php');
                    exit();
                    break;
                
                case 'parecer':
                    header('Location: ../gerenciar_parecer/index.php');
                    exit();
                    break;

                case 'evento':
                    header('Location: ../gerenciar_data/index.php');
                    exit();
                    break;

                case 'relatorio_atividade':
                    header('Location: ../relatorio_atividade/index.php');
                    exit();
                    break;
                
                case 'plano_trabalho':
                    header('Location: ../plano_trabalho/index.php');
                    exit();
                    break;
                
                case 'curso_turma':
                    header('Location: ../curso_turma/index.php');
                    exit();
                    break;
                
                case 'usuario':
                    header('Location: ../gerenciar_usuario/index.php');
                    exit();
                    break;
                
                case 'gerenciar_disciplina':
                    header('Location: ../gerenciar_disciplina/index.php');
                    exit();
                    break;
                
                default:
                    echo "<a class='botao_adicionar_usuarios' href=\"?page=cadastrar\">Adicionar Usuário</a>";
                    echo "<div class='gerenciar_usuarios_titulo'>Gerenciar Usuários</div>";


                    echo "<div class='quadrado_branco_listar_usuarios'>";
                        include("listar.php");
                    echo "</div>";
                    
                    break;
            }
        ?>

    </div>
</body>
</html>
