<?php
    switch($_REQUEST["acao"]){
        
        case 'cadastrar':
            $nome = $_POST["nome"];
            $email = $_POST["email"];
            $categoria = $_POST["categoria"];

            $numero_de_bytes = 4;
            $restultado_bytes = random_bytes($numero_de_bytes);
            $senha = bin2hex($restultado_bytes);

            $sql = "INSERT INTO usuario (nome, email, senha, categoria) 
                    VALUES ('{$nome}', '{$email}', '{$senha}', '{$categoria}')";
            
            $res = $conexao->query($sql);

            if($res == true){
                include("../email_primeiro_acesso.php");
                echo "<script>alert('Cadastrado com sucesso!');</script>";
                echo "<script>location.href='?page=';</script>";
            }

            else{
                echo "<script>alert('Não foi possível cadastrar!');</script>";
                echo "<script>location.href='?page=';</script>";
            }
            break;

        case 'editar':
            $nome = $_POST["nome"];
            $email = $_POST["email"];
            $categoria = $_POST["categoria"];
            
            $sql = "UPDATE usuario 
                    SET 
                        nome = '{$nome}',
                        email = '{$email}',
                        categoria = '{$categoria}'

                    WHERE id_usuario=" . $_REQUEST["id"];

            $res = $conexao->query($sql);

            if($res == true){
                echo "<script>alert('Editado com sucesso!');</script>";
                echo "<script>location.href='?page=';</script>";
            }

            else{
                echo "<script>alert('Não foi possível editar!');</script>";
                echo "<script>location.href='?page=';</script>";
            }
            

            break;

        case 'excluir':
            
            $sql = "DELETE FROM usuario WHERE id_usuario=".$_REQUEST["id"];
            $res = $conexao->query($sql);


            $sql_conselheiro = "UPDATE turma
                                SET
                                    conselheiro = NULL
                                WHERE conselheiro = " . $_REQUEST["id"];
            $res_conselheiro = $conexao->query($sql_conselheiro);

            if($res == true){
                echo "<script>alert('Excluido com sucesso!');</script>";
                echo "<script>location.href='?page=';</script>";
            }

            else{
                echo "<script>alert('Não foi possível excluir!');</script>";
                echo "<script>location.href='?page=';</script>";
            }
            break;
    }
?>