<?php 
    switch ($_REQUEST["acao"]) {
        case 'cadastrar':
            $id_turma = $_REQUEST["idturma"];
            $id_disciplina = $_REQUEST["iddisciplina"];
            $observacao = $_POST["observacao"];

            // insere no banco
            $sql_observacao = "INSERT INTO observacoes (observacao, id_turma, id_disciplina)
                                VALUES ('{$observacao}', '{$id_turma}', '{$id_disciplina}')";

            $res_observacao= $conexao->query($sql_observacao);

            if($res_observacao == true){
                echo "<script>alert('Cadastrado com sucesso!');</script>";
                echo "<script>location.href='?page=listar_observacoes_turma&idturma=".$id_turma."&iddisciplina=".$id_disciplina."';</script>";
            }

            else{
                echo "<script>alert('Não foi possível cadastrar!');</script>";
                echo "<script>location.href='?page=listar_observacoes_turma&idturma=".$id_turma."&iddisciplina=".$id_disciplina."';</script>";
            }

            break;
        
        case 'editar':

            $observacao = $_POST["observacao"];

            //atualiza no banco
            $sql_observacao = "UPDATE observacoes
                                SET observacao = '{$observacao}'
                                WHERE id_observacao = ". $_REQUEST["idobservacao"];
            
            $res_observacao= $conexao->query($sql_observacao);

            if($res_observacao == true){
                echo "<script>alert('Editado com sucesso!');</script>";
                echo "<script>location.href='?page=listar_observacoes_turma&idturma=".$_REQUEST["idturma"]."&iddisciplina=".$_REQUEST["iddisciplina"]."';</script>";
            }

            else{
                echo "<script>alert('Não foi possível editar!');</script>";
                echo "<script>location.href='?page=listar_observacoes_turma&idturma=".$_REQUEST["idturma"]."&iddisciplina=".$_REQUEST["iddisciplina"]."';</script>";
            }

            break;
        
        case 'excluir':
            //exclui os dados da tabela disciplina
            $sql = "DELETE FROM observacoes WHERE id_observacao=".$_REQUEST["idobservacao"];
            $res = $conexao->query($sql);

        
            if(($res == true)){
                echo "<script>alert('Excluido com sucesso!');</script>";
                echo "<script>location.href='?page=listar_observacoes_turma&idturma=".$_REQUEST["idturma"]."&iddisciplina=".$_REQUEST["iddisciplina"]."';</script>";
            }

            else{
                echo "<script>alert('Não foi possível excluir!');</script>";
                echo "<script>location.href='?page=listar_observacoes_turma&idturma=".$_REQUEST["idturma"]."&iddisciplina=".$_REQUEST["iddisciplina"]."';</script>";
            }

            break;

    }
?>