<div class='cadastrar_curso_titulo'>Cadastrar Curso</div>

<div class='container_cadastro_curso'>

<form action="?page=salvar_curso&acao=cadastrar" method="POST">
    <div>
        <label class='texto_cadastrar'>Nome</label> <br>
        <input class='formulario_cadastrar' type="text" name="nome" required>  <br> <br>
    </div>
    <div>
        <label class='texto_cadastrar'>Carga Horária</label> <br>
        <input class='formulario_cadastrar' type="number" name="carga_horaria" required> <br> <br>
    </div>
    <div>
        <label class='texto_cadastrar'>Coordenador de Curso</label> <br>
        <input class='formulario_cadastrar' type="text" name="coordenador"> <br> <br>
    </div>
    <div>
        <label class='texto_cadastrar' >E-mail Coordenador de Curso</label> <br>
        <input class='formulario_cadastrar' type="text" name="email_coord_curso"> <br> <br>
    </div>
    <div>
        <button class='botao_cadastrar_curso' type="submit">Cadastrar</button> <br> 
    </div>
</form>

</div>