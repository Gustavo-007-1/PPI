<?php 
    include("config.php");

    $email = $_POST["email"];
    $nova_senha = password_hash($_POST["novasenha"], PASSWORD_DEFAULT);

    $sql = "UPDATE usuario
            SET senha = '{$nova_senha}'
            WHERE email = '{$email}'";

    $res = $conexao->query($sql);

    if($res == true){
        echo "<script>alert('Senha alterada com sucesso!');</script>";
        echo "<script>location.href='./index.php';</script>";
    }

    else{
        echo "<script>alert('Não foi possível alterar a senha!');</script>";
        echo "<script>location.href='./index.php';</script>";
    }
?>