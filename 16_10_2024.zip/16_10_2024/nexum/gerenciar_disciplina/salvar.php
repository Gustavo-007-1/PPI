<?php 

switch ($_REQUEST["acao"]) {
    case 'cadastrar':
        $disciplina = $_POST["disciplina"];
        $quant_periodos = $_POST["quant_periodos"];
        $id_professor = $_POST["professor"];
        $id_turma = $_POST["turma"];


        // cadastrando dados na tabela disciplina
        $sql_disciplina = "INSERT INTO disciplina (nome, quant_periodos, id_turma, id_professor)
                            VALUES ('{$disciplina}', '{$quant_periodos}', '{$id_turma}', '{$id_professor}')";
        $res_disciplina = $conexao->query($sql_disciplina);


        if(($res_disciplina == true)){
            echo "<script>alert('Cadastrado com sucesso!');</script>";
            echo "<script>location.href='?page=';</script>";
        }

        else{
            echo "<script>alert('Não foi possível cadastrar!');</script>";
            echo "<script>location.href='?page=';</script>";
        }
        break;
    
    case 'editar':
        $disciplina = $_POST["disciplina"];
        $quant_periodos = $_POST["quant_periodos"];
        $id_professor = $_POST["professor"];
        $id_turma = $_POST["turma"];
        $id_disciplina = $_REQUEST["iddisciplina"];

        // atualiza a tabela disciplina
        $sql_disciplina = "UPDATE disciplina 
                    SET 
                        nome = '{$disciplina}',
                        quant_periodos = '{$quant_periodos}',
                        id_turma = '{$id_turma}',
                        id_professor = '{$id_professor}'

                    WHERE id_disciplina = '{$id_disciplina}'";

        $res_disciplina = $conexao->query($sql_disciplina);


        if(($res_disciplina == true)){
            echo "<script>alert('Editado com sucesso!');</script>";
            echo "<script>location.href='?page=';</script>";
        }

        else{
            echo "<script>alert('Não foi possível editar!');</script>";
            echo "<script>location.href='?page=';</script>";
        }

        break;
    
    case 'excluir':
        
        //exclui os dados da tabela disciplina
        $sql_disciplina = "DELETE FROM disciplina WHERE id_disciplina=".$_REQUEST["iddisciplina"];
        $res_disciplina = $conexao->query($sql_disciplina);

        $sql_aluno_disciplina = "DELETE FROM aluno_disciplina
                                    WHERE id_disciplina= " . $_REQUEST["iddisciplina"];
        $res_aluno_disciplina = $conexao->query($sql_aluno_disciplina);

       
        if(($res_disciplina == true) && ($res_aluno_disciplina == true)){
            echo "<script>alert('Excluido com sucesso!');</script>";
            echo "<script>location.href='?page=';</script>";
        }

        else{
            echo "<script>alert('Não foi possível excluir!');</script>";
            echo "<script>location.href='?page=';</script>";
        }

        break;

}

?>