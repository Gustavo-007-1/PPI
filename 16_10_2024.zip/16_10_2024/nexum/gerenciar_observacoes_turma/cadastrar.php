<h1>Registrar Observação</h1>
<form action="?page=salvar_observacoes_turma&acao=cadastrar&idturma=<?php echo $_REQUEST["idturma"];?>&iddisciplina=<?php echo $_REQUEST["iddisciplina"];?>" method="POST">
    <div>
        <label>Observação</label>
        <input type="text" name="observacao" required>
    </div>
    <div>
        <button type="submit">Adicionar</button>
        <button type="submit" formnovalidate>Cancelar</button>
    </div>
</form>