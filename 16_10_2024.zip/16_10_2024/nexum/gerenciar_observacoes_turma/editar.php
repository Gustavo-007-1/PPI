<?php 
    $sql_observacao = "SELECT id_observacao, observacao FROM observacoes WHERE id_observacao=".$_REQUEST["idobservacao"];
    $res_observacao = $conexao->query($sql_observacao);
    $row_observacao = $res_observacao->fetch_object();
?>

<h1>Editar Observação</h1>
<form action="?page=salvar_observacoes_turma&acao=editar&idturma=<?php echo $_REQUEST["idturma"];?>&iddisciplina=<?php echo $_REQUEST["iddisciplina"];?>&idobservacao=<?php echo $_REQUEST["idobservacao"];?>" method="POST">
    <div>
        <label>Observação</label>
        <input type="text" name="observacao" value="<?php echo $row_observacao->observacao;?>">
    </div>
    <div>
        <button type="submit">Salvar</button>
        <button type="submit" formnovalidate>Cancelar</button>
    </div>
</form>