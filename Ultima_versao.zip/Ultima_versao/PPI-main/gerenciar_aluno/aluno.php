<div class="container_info_aluno">

<?php 

    // consulta a tabela aluno
    $sql_aluno = "SELECT *
                FROM aluno
                WHERE id_aluno =" . $_REQUEST["idaluno"];

    $res_aluno = $conexao->query($sql_aluno);
    $row_aluno = $res_aluno->fetch_object();
    $qtd_aluno = $res_aluno->num_rows;

    $sql_nascimento = "SELECT DATE_FORMAT(data_nascimento, '%d/%m/%Y') 
                        AS data_formatada 
                        FROM aluno 
                        WHERE id_aluno=".$_REQUEST["idaluno"];
    $res_nascimento = $conexao->query($sql_nascimento);
    $row_nascimento = $res_nascimento->fetch_object();

    // consulta as tabelas aluno_disciplina, aluno e disciplina
    $sql_nota = "SELECT aluno_disciplina.id_aluno_disciplina, aluno_disciplina.id_aluno, aluno.nome as nome_aluno, aluno.id_aluno, aluno_disciplina.nota_parcial_um, aluno_disciplina.nota_primeiro_semestre, aluno_disciplina.nota_parcial_dois, aluno_disciplina.nota_segundo_semestre, aluno_disciplina.ais, aluno_disciplina.mc, aluno_disciplina.ppi, aluno_disciplina.falta, aluno_disciplina.media_anual, aluno_disciplina.id_disciplina, disciplina.nome as nome_disciplina
    FROM aluno_disciplina INNER JOIN aluno ON aluno_disciplina.id_aluno = aluno.id_aluno
    INNER JOIN disciplina ON aluno_disciplina.id_disciplina = disciplina.id_disciplina
    WHERE aluno_disciplina.id_aluno = " . $_REQUEST["idaluno"];

    $res_nota = $conexao->query($sql_nota);
    $qtd_nota = $res_nota->num_rows;

    switch ($_REQUEST["info"]) {
        case 'ver_mais':
                
                echo "<div class='container_visualizar_info_quialitativa'>";
                echo "<div class='titulo_informacoes_qualitativas'>Informações Qualitativas</div>";

                echo "Cota: " . $row_aluno->cota . " <br>  ";
                echo "Acompanhamento AEE: " . $row_aluno->acompanhamento_aee . "<br>";
                echo "Acompanhamento CAI: " . $row_aluno->acompanhamento_cai . "  <br> ";
                echo "Acompanhamento de Saúde " . $row_aluno->acompanhamento_saude . "<br>";
                echo "Auxílio Permanência: " . $row_aluno->auxilio_permanencia . "  <br> ";
                echo "Apoio Psicológico: " . $row_aluno->apoio_psicologico . "<br>";
                echo "Projeto de Ensino: " . $row_aluno->projeto_ensino . "  <br> ";
                echo "Projeto de Extensão: " . $row_aluno->projeto_extensao . "<br>";
                echo "Projeto de Pesquisa: " . $row_aluno->projeto_pesquisa . "  <br> ";
                echo "Estágio Extracurricular: " . $row_aluno->estagio . "<br>";
                echo "Equipamentos Emprestados: " . $row_aluno->equip_emprest . "<br>";

                if($_SESSION["categoria"]==1 || $_SESSION["categoria"]==2){
                    echo "<button class='botao_editar1_info_qualitativa' onclick=\"location.href='?page=editar_aluno&idaluno=" . $row_aluno->id_aluno . "&idturma=". $row_aluno->id_turma ."&r=aluno';\">Editar</button>";
                    echo " <button class='botao_excluir_info_qualitativa' onclick=\"if(confirm('Tem certeza que deseja excluir?')){location.href='?page=salvar_aluno&acao=excluir&idaluno=".$row_aluno->id_aluno."&idturma=". $row_aluno->id_turma ."';}else{false;}\"'>Excluir</button><br>";
                }
                else{
                    echo "<br>";
                }
   
            echo "</div>";
            break;
        
        case 'simplificada':

            // aqui, se o usuário for um professor, o id da disciplina é enviado também, se não, não
            if($_SESSION["categoria"] != 3){
                echo "<button class='botao_observacoes_aluno' onclick=\"location.href='?page=aluno&info=listar_observacoes_aluno&idaluno=".  $_REQUEST["idaluno"]  . "&idturma=" .  $_REQUEST["idturma"]  . "&iddisciplina=" . NULL . "';\">Observações</button>";
            }
            else{
                echo "<button class='botao_observacoes_aluno' onclick=\"location.href='?page=aluno&info=listar_observacoes_aluno&idaluno=".  $_REQUEST["idaluno"] ."&idturma=" .  $_REQUEST["idturma"] . "&iddisciplina=" . $_REQUEST["iddisciplina"] . "';\">Observações</button>";   
            }

            echo "<br><img class='foto_aluno_gr_aluno1' src=\"../gerenciar_aluno/foto_upload/". $row_aluno->foto."\"/>";
            echo "<div class='texto_nome_info_aluno'>";
            echo $row_aluno->nome . " ";
            echo "</div>";

            echo "<div class='texto_email_info_aluno'>";
            echo $row_aluno->email_institucional . "  ";
            echo "</div>";

            if(($row_aluno->moradia != "Não") || ($row_aluno->moradia != "não")){
                echo "<div class='texto_moradia_info_aluno'>";
                echo $row_aluno->moradia . "<br>";
                echo "</div>";

                echo "<div class='icon_moradia_info_aluno'>";
                echo "<i class='bi bi-house-fill'></i>";
                echo "</div>";
            }
            else{
                echo "<br>";
            }

            echo "<div class='texto_genero_info_aluno'>";
            echo "Gênero: ".$row_aluno->genero . " ";
            echo "</div>";

            echo "<div class='texto_data_nacimento_info_aluno'>";
            echo "Data de Nascimento: " . $row_nascimento->data_formatada . "<br>";
            echo "</div>";

            echo "<div class='texto_cidade_info_aluno'>";
            echo "Cidade: " . $row_aluno->cidade . " - " . $row_aluno->unidade_federativa . " ";
            echo "</div>";
            echo "<div class='texto_matricula_info_aluno'>";
            echo "Matrícula: " . $row_aluno->numero_matricula;
            echo "</div>";

            if($qtd_nota>0){
                echo "<table border=\"1\">";
                    echo "<tr>";
                        echo "<td>Componente Curricular</td>";
                        echo "<td>Nota Parcial - 1º Semestre</td>";
                        echo "<td>Nota Semestral - 1º Semestre</td>";
                        echo "<td>Nota Parcial - 2º Semestre</td>";
                        echo "<td>Nota Semestre - 2º Semestre</td>";
                        echo "<td>AIS</td>";
                        echo "<td>Mostra de Ciências</td>";
                        echo "<td>PPI</td>";
                        echo "<td>Média Anual</td>";
                        echo "<td>Faltas</td>";
                        
                    echo "</tr>";
            
                    while($row_nota = $res_nota->fetch_object()){
                        echo "<tr>";
                            echo "<td>" . $row_nota->nome_disciplina . "</td>";
                            echo "<td>" . $row_nota->nota_parcial_um . "</td>";
                            echo "<td>" . $row_nota->nota_primeiro_semestre. "</td>";
                            echo "<td>" . $row_nota->nota_parcial_dois . "</td>";
                            echo "<td>" . $row_nota->nota_segundo_semestre . "</td>";
                            echo "<td>" . $row_nota->ais . "</td>";
                            echo "<td>" . $row_nota->mc . "</td>";
                            echo "<td>" . $row_nota->ppi . "</td>";   
                            echo "<td>" . $row_nota->media_anual . "</td>"; 
                            echo "<td>" . $row_nota->falta . "</td>";      
                        echo "</tr>";
                    }
                    
                echo "</table>";
            }

            echo "<br><button class='botao_ver_mais_aluno' onclick=\"location.href='?page=aluno&info=ver_mais&idaluno=" . $row_aluno->id_aluno . "&idturma=". $_REQUEST["idturma"] ."';\">Ver mais</button>";

            break;

        case "listar_observacoes_aluno":
            include("../gerenciar_observacoes_aluno/listar.php");
            break;

        case 'cadastrar_observacoes_aluno':
            include("../gerenciar_observacoes_aluno/cadastrar.php");
            break;
        
        case 'editar_observacoes_aluno':
            include("../gerenciar_observacoes_aluno/editar.php");
            break;
        
        case 'salvar_observacoes_aluno':
            include("../gerenciar_observacoes_aluno/salvar.php");
            break;
    }


?>

</div>
</div>