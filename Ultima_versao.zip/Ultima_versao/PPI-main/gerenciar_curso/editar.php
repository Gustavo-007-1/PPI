<div class='cadastrar_curso_titulo'>Editar Curso</div>

<div class='container_editar_curso'>
    <?php 

        $sql="SELECT * FROM curso
            WHERE id_curso=".$_REQUEST["id"];

        $res = $conexao->query($sql);
        $row = $res->fetch_object();

    ?>


    <form action="?page=salvar_curso&acao=editar" method="POST">
        <input type="hidden" name="id" value="<?php echo $row->id_curso; ?>">
        <div>
            <label class='texto_editar1'>Nome</label>
            <input class='formulario_editar1' type="text" name="nome" value="<?php echo $row->nome; ?>">
        </div>
        <div>
            <label class='texto_editar2'>Carga Horária</label>
            <input class='formulario_editar2' type="number" name="carga_horaria" value="<?php echo $row->carga_horaria; ?>">
        </div>
        <div>
            <label class='texto_editar3'>Coordenador de Curso</label>
            <input class='formulario_editar3' type="text" name="coordenador" value="<?php echo $row->coordenador; ?>">
        </div>
        <div>
            <button class='botao_cadastrar_curso' type="submit">Salvar</button>
        </div>
    </form>

</div>