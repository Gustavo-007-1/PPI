<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Nexum</title>
    </head>
    <body>
        <h1>Recuperar a Senha</h1>
        <div>
            <form action="recuperar_senha.php" method="POST">
                <div>
                    <label>E-mail</label>
                    <input type="e-mail" name="email">
                </div>
                <div>
                    <label>Nova Senha</label>
                    <input type="password" name="senha_nova">
                </div>
                <div>
                    <label>Confirmar a Nova Senha</label>
                    <input type="password" name="senha_confirmar">
                </div>
                <div>
                    <button type="submit">Enviar</button>
                </div>
            </form>
        </div>
    </body>
</html>
