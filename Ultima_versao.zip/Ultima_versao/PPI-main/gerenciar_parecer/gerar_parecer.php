<?php 

include ("../config.php");

// recebendo os dados
$turma = $_POST["turma"];
$texto_parecer = $_POST["texto_parecer"];

// carregar o composer
require './vendor/autoload.php';

// referenciar o namespace Dompdf
use Dompdf\Dompdf;

// instanciar e usar a dompdf
$dompdf = new Dompdf(['enable_remote' => true]);

// informações do pdf
$dados = "<!DOCTYPE html>";
$dados .= "<html lang=\"pt-br\">";
$dados .= "<head>";
$dados .= "<meta charset=\"UTF-8\">";
$dados .= "<style>
            table { width: 100%; border-collapse: collapse; }
            table, th, td { border: 1px solid black; padding: 8px; text-align: left; }
            th { background-color: #f2f2f2; }
            h2, h3 { margin-bottom: 10px; }
            .small { font-size: 0.8em; color: #555; }
          </style>";
$dados .= "</head>";
$dados .= "<body>";


    // consulta no bd para obter todos os alunos da turma
    $sql_alunos = "SELECT aluno.id_aluno, aluno.nome AS nome_aluno, aluno.numero_matricula, turma.numero AS numero_turma
                   FROM aluno
                   INNER JOIN turma ON aluno.id_turma = turma.id_turma
                   WHERE aluno.id_turma = " . intval($turma);

    $res_alunos = $conexao->query($sql_alunos);
    if (!$res_alunos) {
        die("Erro na consulta: " . $conexao->error);
    }

    // Gerar páginas para cada aluno
    while ($info = $res_alunos->fetch_object()) {
        $dados .= "<div style='page-break-after: always;'></div>";
        $dados .= "<h3>Aluno: " . htmlspecialchars($info->nome_aluno) . " (" . htmlspecialchars($info->numero_matricula) . ") - Turma " . htmlspecialchars($info->numero_turma) . "</h3>";

        $dados .= "<p> " . $texto_parecer . "</p>";

        // Adiciona a segunda página com desempenho escolar
        $dados .= "<div style='page-break-after: always;'></div>";
        $dados .= "<h3>Desempenho escolar do(a) " . htmlspecialchars($info->nome_aluno) . " (" . htmlspecialchars($info->numero_matricula) . ")</h3>";
        
        $dados .= "<table>";
        $dados .= "<tr>
                    <th>Disciplina</th>
                    <th>Nota</th>
                    <th>Faltas</th>
                </tr>";

        // Consulta para obter todas as disciplinas, notas e faltas do aluno
        $sql_disciplinas = "SELECT disciplina.nome AS nome_disciplina, disciplina.id_disciplina,
                                   aluno_disciplina.nota_parcial_um, aluno_disciplina.falta,
                                   usuario.email AS email_professor
                            FROM aluno_disciplina
                            INNER JOIN disciplina ON aluno_disciplina.id_disciplina = disciplina.id_disciplina
                            INNER JOIN usuario ON disciplina.id_professor = usuario.id_usuario
                            WHERE aluno_disciplina.id_aluno = " . $info->id_aluno;

        $res_disciplinas = $conexao->query($sql_disciplinas);

        if ($res_disciplinas && $res_disciplinas->num_rows > 0) {
            // Adicionar linha para cada disciplina do aluno
            while ($disciplina = $res_disciplinas->fetch_object()) {
                $dados .= "<tr>";
                $dados .= "<td>" . htmlspecialchars($disciplina->nome_disciplina) . "<br><span class='small'>" . htmlspecialchars($disciplina->email_professor) . "</span></td>";
                $dados .= "<td>" . htmlspecialchars($disciplina->nota_parcial_um) . "</td>";
                $dados .= "<td>" . htmlspecialchars($disciplina->falta) . "</td>";
                $dados .= "</tr>";
            }
        } else {
            $dados .= "<tr><td colspan='3'>Nenhuma disciplina encontrada</td></tr>";
        }

        $dados .= "</table>";
    }

    $dados .= "</body>";
    $dados .= "</html>";

    // Instanciar o método loadHtml e enviar o conteúdo do PDF
    $dompdf->loadHtml($dados);

    // Configurar o tamanho e a orientação do papel
    $dompdf->setPaper('A4', 'portrait');

    // Renderizar o HTML como PDF
    $dompdf->render();

    // Remover qualquer saída anterior
    ob_clean();

    // Gerar PDF
    $dompdf->stream("relatorio_turma.pdf", ["Attachment" => false]);
?>
