<div class='listar_observacoes_turma_titulo'>Registrar Observação</div>

<div class="container_observacoes_turma">
    <form action="?page=salvar_observacoes_turma&acao=cadastrar&idturma=<?php echo $_REQUEST["idturma"];?>&iddisciplina=<?php echo $_REQUEST["iddisciplina"];?>" method="POST">
        <div>
            <label>Observação</label> <br>
            <textarea class='caixa_editar_observacao' name="observacao" required></textarea>
        </div>
        <div>
            <button class='botao_editar_observacao_turma' type="submit">Salvar</button>
        </div>
    </form>
</div>