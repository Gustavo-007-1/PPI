<?php 

switch ($_REQUEST["acao"]) {
    case 'cadastrar':
        $disciplina = $_POST["disciplina"];
        $quant_periodos = $_POST["quant_periodos"];
        $id_professor = $_POST["professor"];
        $id_turma = $_POST["turma"];


        // cadastrando dados na tabela disciplina
        $sql_disciplina = "INSERT INTO disciplina (nome, quant_periodos, id_turma)
                            VALUES ('{$disciplina}', '{$quant_periodos}', '{$id_turma}')";
        $res_disciplina = $conexao->query($sql_disciplina);


        // pegando o id da disciplina 
        $id_disciplina = $conexao->insert_id;


        // cadastrando dados na tabela disciplina_professor
        $sql_disciplina_professor = "INSERT INTO disciplina_professor (id_professor, id_disciplina)
                                    VALUES ('{$id_professor}', '{$id_disciplina}')";
        $res_disciplina_professor = $conexao->query($sql_disciplina_professor);


        if(($res_disciplina == true) && ($res_disciplina_professor == true)){
            echo "<script>alert('Cadastrado com sucesso!');</script>";
            echo "<script>location.href='?page=';</script>";
        }

        else{
            echo "<script>alert('Não foi possível cadastrar!');</script>";
            echo "<script>location.href='?page=';</script>";
        }
        break;
    
    case 'editar':
        $disciplina = $_POST["disciplina"];
        $quant_periodos = $_POST["quant_periodos"];
        $id_professor = $_POST["professor"];
        $id_turma = $_POST["turma"];
        $id_disciplina = $_REQUEST["iddisciplina"];

        // atualiza a tabela disciplina
        $sql_disciplina = "UPDATE disciplina 
                    SET 
                        nome = '{$disciplina}',
                        quant_periodos = '{$quant_periodos}',
                        id_turma = '{$id_turma}'

                    WHERE id_disciplina = '{$id_disciplina}'";

        $res_disciplina = $conexao->query($sql_disciplina);

        // atualiza a tabela disciplina_professor
        $sql_disciplina_professor = "UPDATE disciplina_professor
                                    SET 
                                        id_professor = '{$id_professor}',
                                        id_disciplina = '{$id_disciplina}'
                                    WHERE id_disciplina = '{$id_disciplina}'";

        $res_disciplina_professor = $conexao->query($sql_disciplina_professor);


        if(($res_disciplina == true) && ($res_disciplina_professor == true)){
            echo "<script>alert('Editado com sucesso!');</script>";
            echo "<script>location.href='?page=';</script>";
        }

        else{
            echo "<script>alert('Não foi possível editar!');</script>";
            echo "<script>location.href='?page=';</script>";
        }

        break;
    
    case 'excluir':
        
        //exclui os dados da tabela disciplina
        $sql_disciplina = "DELETE FROM disciplina WHERE id_disciplina=".$_REQUEST["iddisciplina"];
        $res_disciplina = $conexao->query($sql_disciplina);

        //exclui os dados da tabela disciplina_professor
        $sql_disciplina_professor = "DELETE FROM disciplina_professor WHERE id_disciplina=".$_REQUEST["iddisciplina"];
        $res_disciplina_professor = $conexao->query($sql_disciplina_professor);

        //exclui os dados da tabela turma_disciplina
        $sql_turma_disciplina = "DELETE FROM turma_disciplina WHERE id_disciplina=".$_REQUEST["iddisciplina"];
        $res_turma_disciplina = $conexao->query($sql_turma_disciplina);

       
        if(($res_disciplina == true) && ($res_disciplina_professor == true) && ($res_turma_disciplina == true)){
            echo "<script>alert('Excluido com sucesso!');</script>";
            echo "<script>location.href='?page=';</script>";
        }

        else{
            echo "<script>alert('Não foi possível excluir!');</script>";
            echo "<script>location.href='?page=';</script>";
        }

        break;

}

?>