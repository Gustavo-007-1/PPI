<?php 
    session_start();
    if (empty($_SESSION)) {
        header('Location: ../index.php');
        exit();
    }

?>
<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Nexum</title>
    </head>
    <body>
        <h1><a href="?page=principal">Nexum</a></h1>
        <?php 
            echo "<a href=\"?page=logout\">Sair</a>";
        ?>
        <h2>Alterar Senha</h2>
        <form action="./pagina_principal.php?page=alterar" method="POST">
            <div>
                <label>Senha Atual</label>
                <input type="password" name="senha_atual">
            </div>
            <div>
                <label>Nova Senha</label>
                <input type="password" name="senha_nova">
            </div>
            <div>
                <label>Confirmar a Nova Senha</label>
                <input type="password" name="senha_confirmar">
            </div>
            <div>
                <button type="submit">Enviar</button>
            </div>
        </form>
    </body>
</html>