<?php 
    $sql_observacao = "SELECT id_aluno_disciplina, observacao FROM aluno_disciplina WHERE id_aluno_disciplina=".$_REQUEST["idalunodisciplina"];
    $res_observacao = $conexao->query($sql_observacao);
    $row_observacao = $res_observacao->fetch_object();
?>

<h1>Editar Observação</h1>
<form action="?page=aluno&info=salvar_observacoes_aluno&acao=editar&idturma=<?php echo $_REQUEST["idturma"];?>&iddisciplina=<?php echo $_REQUEST["iddisciplina"];?>&idaluno=<?php echo $_REQUEST["idaluno"]?>&idalunodisciplina=<?php echo $_REQUEST["idalunodisciplina"];?>" method="POST">
    <div>
        <label>Observação</label>
        <textarea name="observacao"><?php echo $row_observacao->observacao;?></textarea>
    </div>
    <div>
        <button type="submit">Salvar</button>
        <button type="submit" formnovalidate>Cancelar</button>
    </div>
</form>