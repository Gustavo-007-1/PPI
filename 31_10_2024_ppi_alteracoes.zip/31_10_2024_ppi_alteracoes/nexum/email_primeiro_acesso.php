<?php 
    require_once('../src/PHPMailer.php');
    require_once('../src/SMTP.php');
    require_once('../src/Exception.php');

    use PHPMailer\PHPMailer\PHPMailer;
    use PHPMailer\PHPMailer\SMTP;
    use PHPMailer\PHPMailer\Exception;

    $mail = new PHPMailer(true);

    try {
        $email = $_POST["email"];
        $mail->isSMTP();
        $mail->Host = 'smtp.gmail.com';
        $mail->SMTPAuth = true;
        $mail->Username = 'nexum.inf@gmail.com';
        $mail->Password = 'tlojntypjtymyczs';
        $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
        $mail->Port = 587;

        $mail->setFrom('nexum.inf@gmail.com');
        $mail->addAddress($email);

        $mail->isHTML(true);
        $mail->Subject = 'Senha';
        $mail->Body = 'Para alterar e recuperar a senha de acesso ao sistema, acesse o endereço abaixo: <a href="http://localhost:8080/nexum/recuperar_senha_form.php">http://localhost:8080/nexum/recuperar_senha_form.php</a>';
        $mail->AltBody = 'Para alterar e recuperar a senha de acesso ao sistema, acesse o endereço abaixo: http://localhost:8080/nexum/recuperar_senha_form.php';

        if($mail->send()){
            echo "<script>alert('E-mail enviado com sucesso!');</script>";
            echo "<script>location.href='./index.php';</script>";
        }

    } catch(Exception $e){
        echo "<script>alert('Erro ao enviar e-mail!');</script>";
        echo "<script>location.href='./index.php';</script>";
    }
?>
