<?php 
    session_start();
    if (empty($_SESSION)) {
        header('Location: ../index.php');
        exit();
    }

    include("config.php");

    $senha_atual = $_POST["senha_atual"];
    $senha_nova = $_POST["senha_nova"];
    $senha_confirmar = $_POST["senha_confirmar"];

    # faz a consulta e seleção no bd
    $sql_puxa_senha = "SELECT senha FROM usuario
            WHERE id_usuario = ". $_SESSION["id_usuario"];

    $res_puxa_senha = $conexao->query($sql_puxa_senha) or die($conexao->error);
    $row = $res_puxa_senha->fetch_object();

    if(password_verify($senha_atual, $row->senha)){
        if($senha_nova == $senha_confirmar){

            $nova_senha = password_hash($senha_nova, PASSWORD_DEFAULT);

            # faz a atualização da senha no bd
            $sql_muda_senha = "UPDATE usuario
                                SET senha = '{$nova_senha}' 
                                WHERE id_usuario= ". $_SESSION["id_usuario"];

            $res_muda_senha = $conexao->query($sql_muda_senha) or die($conexao->error);

            if($res_muda_senha == true){
                echo "<script>alert('Senha alterada com sucesso!');</script>";
                echo "<script>location.href='./pagina_principal.php';</script>";
            }
        
            else{
                echo "<script>alert('Não foi possível alterar a senha!');</script>";
                echo "<script>location.href='./pagina_principal.php';</script>";
            }

        }
        else if($senha_nova != $senha_confirmar){
            echo "<script>alert('As senhas são diferentes!');</script>";
            echo "<script>location.href='alterar_senha.php';</script>";
        }
        
    }

    else{
        echo "<script>alert('A senha atual informada está incorreta');</script>";
        echo "<script>location.href='./alterar_senha.php';</script>";
    }
?>