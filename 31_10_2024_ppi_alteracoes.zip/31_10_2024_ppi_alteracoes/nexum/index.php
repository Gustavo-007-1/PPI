<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login - Nexum</title>
</head>
<body>
    <div>
        <form action="login.php" method="POST">
            <div>
                <label>E-Mail</label>
                <input type="e-mail" name="email">
            </div>
            <div>
                <label>Senha</label>
                <input type="password" name="senha">
            </div>
            <div>
                <button type="submit">Enviar</button>
            </div>
        </form>
        <a href="esqueceu_senha_form.php">Esqueceu a senha?</a>
    </div>
</body>
</html>