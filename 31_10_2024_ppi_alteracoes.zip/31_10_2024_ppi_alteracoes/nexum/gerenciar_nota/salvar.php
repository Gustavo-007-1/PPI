<?php 
    if(($_SERVER["REQUEST_METHOD"] == "POST") && isset($_POST["notas"])){
        foreach ($_POST["notas"] as $id_aluno_disciplina => $notas) {
            $nota_parcial_um = $notas["nota_parcial_um"];
            $nota_primeiro_semestre = $notas["nota_primeiro_semestre"];
            $nota_parcial_dois = $notas["nota_parcial_dois"];
            $nota_segundo_semestre = $notas["nota_segundo_semestre"];
            $ais = $notas["ais"];
            $mc = $notas["mc"];
            $ppi = $notas["ppi"];
            $media_anual = (($nota_primeiro_semestre*40)+($nota_segundo_semestre*60))/100;
            $media_anual = number_format($media_anual, 2, '.', ' ');

            $sql = "UPDATE aluno_disciplina SET 
                nota_parcial_um = '{$nota_parcial_um}',
                nota_primeiro_semestre = '{$nota_primeiro_semestre}',
                nota_parcial_dois = '{$nota_parcial_dois}',
                nota_segundo_semestre = '{$nota_segundo_semestre}',
                ais = '{$ais}',
                mc = '{$mc}',
                ppi = '{$ppi}',
                media_anual = '{$media_anual}'
                WHERE id_aluno_disciplina = $id_aluno_disciplina";

            $conexao->query($sql);
        }
        echo "<script>alert('Editado com sucesso!');</script>";
        echo "<script>location.href='?page=notas_turma&idturma=".$_REQUEST["idturma"]."&iddisciplina=".$_REQUEST["iddisciplina"]."';</script>";
    }
?>