<?php 

    // recebendo os dados 
    $turma = $_POST["turma"];
    $aluno = $_POST["aluno"];

     // carregar o composer
     require './vendor/autoload.php';

     //referecniar o namespace Dompdf
     use Dompdf\Dompdf;
 
     // instanciar e usar a dompdf
     $dompdf = new Dompdf(['enable_remote' => true]);

    if (isset($_FILES["pdf"]) && $_FILES["pdf"]["error"] == 0) {
        // Carrega o conteúdo do PDF diretamente do arquivo temporário
        $pdfContent = file_get_contents($_FILES["pdf"]["tmp_name"]);

        // consulta no bd
        $sql = "SELECT aluno_disciplina.id_aluno_disciplina, aluno_disciplina.id_aluno, aluno.nome as nome_aluno, aluno.matricula, aluno.id_aluno, aluno.id_turma, aluno_disciplina.falta, aluno_disciplina.media_anual, aluno_disciplina.id_disciplina, disciplina.nome as nome_disciplina, disciplina.id_professor, usuario.id_usuario, usuario.nome as nome_usuario, usuario.email
        FROM aluno_disciplina INNER JOIN aluno ON aluno_disciplina.id_aluno = aluno.id_aluno
        INNER JOIN disciplina ON aluno_disciplina.id_disciplina = disciplina.id_disciplina
        INNER JOIN usuario ON disciplina.id_professor = usuario.id_usuario
        WHERE aluno.id_turma = " . $turma;
        $res = $conexao->prepare($sql);
        $res->execute();

        $sql_turma = "SELECT numero FROM turma WHERE id_turma = " . $turma;
        $res_turma = $conexao->query($sql_turma);
        $row_turma = $res_turma->fetch_object();

        //lê os registros do bd
        while($row = $res->fetch(PDO::FETCH_ASSOC)){
            extract($row);
            $dados = "Aluno" . $nome_aluno . "(". $matricula .") - Turma " . $row_turma->numero;
            $dados .= "<div style='page-break-after: always;'></div>"; // Quebra de página
            $dados .= "<embed src='data:application/pdf;base64," . base64_encode($pdfContent) . "' 
                    type='application/pdf' width='100%' height='800px' />";
            
            $dados .= "<table border=\"1\">";
            $dados .= "<tr>";
            $dados .= "<td>Disciplina</td>";
            $dados .= "<td>Nota</td>";
            $dados .= "<td>Falta</td>";
                
        }
    }

?>