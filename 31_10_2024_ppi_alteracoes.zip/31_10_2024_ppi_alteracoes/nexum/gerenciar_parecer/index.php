<?php 
    session_start();
    if (empty($_SESSION)) {
        header('Location: ./index.php');
        exit();
    }

    include ("../config.php");
    switch (@$_REQUEST["page"]){
        case 'gerar_parecer':
            include("./gerar_parecer.php");
            break;

        default:
            break;
    }

    #consulta a tabela turma
    $sql_turma = "SELECT id_turma, numero FROM turma
                    ORDER BY numero ASC";

    $res_turma = $conexao->query($sql_turma);
    $qtd_turma = $res_turma->num_rows;

    #consulta a tabela turma
    $sql_aluno = "SELECT id_aluno, nome FROM aluno
                    ORDER BY nome ASC";

    $res_aluno = $conexao->query($sql_aluno);
    $qtd_aluno = $res_aluno->num_rows;

?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Nexum</title>

</head>
<body>
    <div>
        <h1><a href="?page=principal">Nexum</a></h1>
        <?php 
            echo "<a href=\"?page=logout\">Sair</a>";
        ?>
    </div>
    <div>
        <h2>Parecer</h2>
        <form action="?page=gerar_parecer" enctype="multipart/form-data" method="POST">

            <label>Texto do Parecer</label>
            <input type='file' id="pdf" name="pdf" required accept="application/pdf">

            <label>Turma</label>
            <select name="turma">
                <option value=" " selected> </option>;
                <?php
                        if($qtd_turma>0){
                            while($row_turma = $res_turma->fetch_object()){
                                echo "<option value=\"". $row_turma->id_turma."\">". $row_turma->numero ."</option>";
                            }
                        }  
                ?>
            </select>

           <br><br> 
           Para gerar o parecer de um aluno específico:
           
            <select name="aluno">
                <option value=" " selected> </option>;
                <?php
                        if($qtd_aluno>0){
                            while($row_aluno = $res_aluno->fetch_object()){
                                echo "<option value=\"". $row_aluno->id_aluno."\">". $row_aluno->nome ."</option>";
                            }
                        }  
                ?>
            </select><br><br>

            <button type="submit">Gerar Pareceres</button>

        </form>
    </div>
</body>
</html>
