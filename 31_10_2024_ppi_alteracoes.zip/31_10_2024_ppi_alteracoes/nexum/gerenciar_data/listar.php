<?php 
            $sql = "SELECT * FROM datas
                    ORDER BY data";
            $res = $conexao->query($sql);
            $qtd = $res->num_rows;


            if ($qtd > 0) {

                while ($row = $res->fetch_object()){

                    echo "<div>";
                        $date1 = DateTime::createFromFormat('Y-m-d', $row->data);
                        echo $date1->format('d/m/Y') . " - " . $row->nome . "  ";

                        if($_SESSION["id_usuario"] == $row->id_usuario){
                            echo "<button onclick=\"location.href='?page=editar&id_data=" . $row->id_data . "';\">Editar</button>";
                            echo "<button onclick=\"if(confirm('Tem certeza que deseja excluir?')){location.href='?page=salvar&acao=excluir&id_data=".$row->id_data."';}else{false;}\"'>Excluir</button>";
                        }
                        else{
                            echo "<br><br>";
                        }
        
                    echo "</div>";
                }
            }
            else{
                echo "Não há eventos registrados no sistema";
            }
        ?>