<h1>Editar Usuários</h1>

<?php 
    // consulta aos dados das datas
    $sql = "SELECT * FROM datas
            WHERE id_data=" . $_REQUEST["id_data"];

    $res= $conexao->query($sql);
    $row = $res->fetch_object();
?>

<form action="?page=salvar&acao=editar&id_data=<?php echo $_REQUEST["id_data"];?>" method="POST">
    <div>
        <label>Nome</label>
        <input type="text" name="nome" value="<?php echo $row->nome;?>">
    </div>
    <div>
        <label>Data</label>
        <input type="date" name="data" value="<?php echo $row->data;?>">
    </div>
    <div>
        <label>Descrição<br></label>
        <textarea name="descricao"><?php echo $row->descricao;?></textarea>
    </div>
    <div>
        <button type="submit">Salvar</button>
        <button type="submit" formnovalidate>Cancelar</button>
    </div>
</form>