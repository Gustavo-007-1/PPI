<div>
    <h2>Parecer</h2>
            <form enctype="multipart/form-data" action="?page=salvar&acao=cadastrar" method="POST">
                <div>
                    <label>Texto do Parecer</label>
                    <textarea name="texto_parecer" required></textarea>
                    <br>
                <div>
                
                <div>
                    <label>Imagem</label>
                    <input type='file' name="imagem">
                    <br>
                </div>

                <div>
                    <h3>Contato Direção de Ensino</h3>

                    <label>Nome do Diretor(a) de Ensino</label>
                    <input type='text' name="nome_diretor_ensino">
                    <br><br>
                    <label>E-mail da Direção</label>
                    <input type='email' name="email_diretor_ensino">
                    <br><br>
                </div>

                <div>
                    <h3>Contato Coordenação de Ensino</h3>

                    <label>Nome do Coordenador(a) de Ensino</label>
                    <input type='text' name="nome_coor_ensino">
                    <br><br>

                    <label>E-mail da Coordenação</label>
                    <input type='email' name="email_coor_ensino">
                    <br><br>
                </div>

                <div>
                    <h3>Contato Coordenação de Assitência Estudantil</h3>

                    <label>Nome do Coordenador(a)</label>
                    <input type='text' name="nome_coor_cae">
                    <br><br>

                    <label>E-mail da Coordenação</label>
                    <input type='email' name="email_coor_cae">
                    <br><br>
                </div>

                <button type="submit">Cadastrar</button>

            </form>
</div>