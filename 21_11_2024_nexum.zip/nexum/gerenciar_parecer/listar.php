<?php 
    $sql = "SELECT * FROM parecer";
    
    $res = $conexao->query($sql);
    $qtd = $res->num_rows;

    if($qtd>0){
        while($row = $res->fetch_object()){
            echo "<h3>Parecer</h3>";
            echo "<p>" . $row->texto . "</p><br>";

            echo "<br><img src=\"../gerenciar_parecer/imagem_parecer/". $row->imagem."\"/>";

            echo "<br><br>Contatos: <br><br>";

            echo $row->nome_diretor_ensino;
            echo "<br> Direção de Ensino";
            echo "<br>Contato: " . $row->email_diretor_ensino . "<br><br>";

            echo $row->nome_coor_ensino;
            echo "<br> Coordenação Geral de Ensino";
            echo "<br>Contato: " . $row->email_coor_ensino . "<br><br>";

            echo $row->nome_coor_cae;
            echo "<br> Coordenação de Assistência Estudantil";
            echo "<br>Contato: " . $row->email_coor_cae . "<br><br>";

            echo "<button onclick=\"location.href='?page=editar_texto&idparecer=" . $row->id_parecer . "';\">Editar</button>";
            echo " <button onclick=\"if(confirm('Tem certeza que deseja excluir?')){location.href='?page=salvar&acao=excluir&idparecer=" . $row->id_parecer . "';}else{false;}\"'>Excluir</button><br>";
        }
    }
    else{
        echo "<a href=\"?page=cadastrar_texto\">Cadastrar Texto</a>"; 
        echo "<h2>Parecer</h2>";
        echo "<br>Não há parecer cadastrado";
    }

?>