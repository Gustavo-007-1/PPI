<?php 
    session_start();
    if (empty($_SESSION)) {
        header('Location: ./index.php');
        exit();
    }

?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Nexum</title>

</head>
<body>
    <div>
        <h1><a href="?page=principal">Nexum</a></h1>
        <?php 
            echo "<a href=\"?page=logout\">Sair</a><br><br>";
            include("../config.php");
            switch(@$_REQUEST["page"]){
                case 'cadastrar_texto':
                    include('./cadastrar.php');
                    break;
                
                case 'editar_texto':
                    include('./editar.php');
                    break;
                
                case 'salvar':
                    include('./salvar.php');
                    break;
                
                case 'principal':
                    header('Location: ../pagina_principal.php');
                    exit();
                    break;
                
                case 'logout':
                    header('Location: ../logout.php');
                    exit();
                    break;
                
                default:       
                    include("./listar.php");
                    break;
             }
        ?>
    </div>
    
</body>
</html>
