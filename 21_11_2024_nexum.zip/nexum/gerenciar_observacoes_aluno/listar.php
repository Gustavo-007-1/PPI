<h1>Observações Sobre o Aluno</h1>
<?php 
    // selecionar no banco as observações existentes e listá-las
    $sql_observacao = "SELECT aluno_disciplina.id_aluno_disciplina, aluno_disciplina.observacao, aluno_disciplina.id_disciplina, aluno_disciplina.id_aluno, disciplina.nome
                    FROM aluno_disciplina INNER JOIN disciplina
                    ON aluno_disciplina.id_disciplina = disciplina.id_disciplina
                    WHERE aluno_disciplina.id_aluno = " . $_REQUEST["idaluno"];

    $res_observacao = $conexao->query($sql_observacao);
    $qtd_observacao = $res_observacao->num_rows;         

    //opções de criar nova observação
    if($_SESSION["categoria"]==3){
        echo "<button onclick=\"location.href='?page=aluno&info=cadastrar_observacoes_aluno&idaluno=".  $_REQUEST["idaluno"] ."&idturma=" .  $_REQUEST["idturma"] . "&iddisciplina=" . $_REQUEST["iddisciplina"] . "';\">Cadastrar</button>";   
    }   

    // lista as observacoes existentes no bd
        if($qtd_observacao>0){
            while ($row_observacao = $res_observacao->fetch_object()) {
                    echo "<div>";
                        if($row_observacao->observacao != NULL){
                            echo $row_observacao->nome . "<br>";
                            echo $row_observacao->observacao . "<br><br>";

                            if ($row_observacao->id_disciplina == $_REQUEST["iddisciplina"]) {

                                echo "<button onclick=\"location.href='?page=aluno&info=editar_observacoes_aluno&idaluno=".  $_REQUEST["idaluno"] ."&idturma=".$_REQUEST["idturma"]."&iddisciplina=" . $row_observacao->id_disciplina ."&idalunodisciplina=".$row_observacao->id_aluno_disciplina."';\">Editar</button>";

                                echo " <button onclick=\"if(confirm('Tem certeza que deseja excluir?')){location.href='?page=aluno&info=salvar_observacoes_aluno&acao=excluir&idaluno=".  $_REQUEST["idaluno"] ."&idturma=".$_REQUEST["idturma"]."&iddisciplina=".$row_observacao->id_disciplina ."&idalunodisciplina==".$row_observacao->id_aluno_disciplina."';}else{false;}\"'>Excluir</button><br>";
                            }
                        }

                    echo "</div>";
            }
        }
?>