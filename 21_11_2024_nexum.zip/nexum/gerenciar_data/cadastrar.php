<h1>Cadastrar Evento</h1>
<form action="?page=salvar&acao=cadastrar" method="POST">
    <div>
        <label>Nome</label>
        <input type="text" name="nome" required>
    </div>
    <div>
        <label>Data</label>
        <input type="date" name="data" required>
    </div>
    <div>
        <label>Descrição<br></label>
        <textarea name="descricao" required></textarea>
    </div>
    <div>
        <button type="submit">Adicionar</button>

    </div>
</form>