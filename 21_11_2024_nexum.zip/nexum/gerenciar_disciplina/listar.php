<?php 
    $sql_turma_disciplina = "SELECT turma.numero, disciplina.nome, disciplina.id_disciplina, disciplina.id_turma
                            FROM turma, disciplina
                            WHERE turma.id_turma = disciplina.id_turma
                            ORDER BY turma.numero";
    
    $res_turma_disciplina = $conexao->query($sql_turma_disciplina);
    $qtd_turma_disciplina = $res_turma_disciplina->num_rows;
    if($qtd_turma_disciplina>0){
        while($row_turma_disciplina = $res_turma_disciplina->fetch_object()){
            echo "Turma ". $row_turma_disciplina->numero . " - ".$row_turma_disciplina->nome;
            echo "<button onclick=\"location.href='?page=editar&iddisciplina=" . $row_turma_disciplina->id_disciplina . "&idturma=". $row_turma_disciplina->id_turma ."';\">Editar</button>";
            echo " <button onclick=\"if(confirm('Tem certeza que deseja excluir?')){location.href='?page=salvar&acao=excluir&iddisciplina=".$row_turma_disciplina->id_disciplina."';}else{false;}\"'>Excluir</button><br>";
        }
    }

?>