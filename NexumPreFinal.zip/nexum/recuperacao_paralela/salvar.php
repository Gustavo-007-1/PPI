<?php 
    $id_turma = $_REQUEST["idturma"];
    $id_disciplina = $_REQUEST["iddisciplina"];
    $nome_disciplina = $_REQUEST["nomedisciplina"];
    $numero_turma = $_REQUEST["numeroturma"];
    $semestre = $_POST["semestre"];

    $arquivo = $_FILES["rel_recup_para"];

    if (!preg_match("/^application\/pdf$/", $arquivo["type"])) {
        $error[1] = "O arquivo enviado não é um PDF.";
    }
    // Pega extensão do arquivo
    preg_match("/\.pdf$/i", $arquivo["name"], $ext);
    
    // Gera um nome único para o relatorio
    $nome_arquivo = "recuperacao_paralela_".$numero_turma."_".$nome_disciplina."_".$semestre."_semestre" . $ext[0];

    // Caminho de onde ficará o arquivo
    $caminho_arquivo = "../recuperacao_paralela/relatorio_recup_para/" . $nome_arquivo;
        
    // Faz o upload da imagem para seu respectivo caminho
    move_uploaded_file($arquivo["tmp_name"], $caminho_arquivo);

    // salvando as informações no bd

    if($semestre == "primeiro"){
        $sql = "UPDATE disciplina
                SET recuperacao_paralela1 = '{$nome_arquivo}'
                WHERE id_disciplina = '{$id_disciplina}'";

        $res = $conexao->query($sql);
    }
    else if($semestre == "segundo"){
        $sql = "UPDATE disciplina
                SET recuperacao_paralela2 = '{$nome_arquivo}'
                WHERE id_disciplina = '{$id_disciplina}'";

        $res = $conexao->query($sql);
    }

    if($res == true){
        echo "<script>alert('Enviado com sucesso!');</script>";
        echo "<script>location.href='?page=recuperacao_paralela&idturma=". $_REQUEST["idturma"] . "&iddisciplina=" . $_REQUEST["iddisciplina"]. "';</script>";
    }

    else{
        echo "<script>alert('Não foi possível enviar!');</script>";
        echo "<script>location.href='?page=recuperacao_paralela&idturma=". $_REQUEST["idturma"] . "&iddisciplina=" . $_REQUEST["iddisciplina"]. "';</script>";
    }
    
?>