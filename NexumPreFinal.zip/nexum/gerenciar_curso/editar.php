<div class='cadastrar_curso_titulo'>Editar Curso</div>

<div class='container_editar_curso'>
    <?php 

        $sql="SELECT * FROM curso
            WHERE id_curso=".$_REQUEST["id"];

        $res = $conexao->query($sql);
        $row = $res->fetch_object();

    ?>


    <form action="?page=salvar_curso&acao=editar" method="POST">
        <input type="hidden" name="id" value="<?php echo $row->id_curso; ?>">
        <div>
            <label class='texto_editar'>Nome</label> <br>
            <input class='formulario_editar' type="text" name="nome" value="<?php echo $row->nome; ?>">  <br> <br>
        </div>
        <div>
            <label class='texto_editar'>Carga Horária</label> <br>
            <input class='formulario_editar' type="number" name="carga_horaria" value="<?php echo $row->carga_horaria; ?>"> <br> <br>
        </div>
        <div>
            <label class='texto_editar'>Coordenador de Curso</label> <br>
            <input class='formulario_editar' type="text" name="coordenador" value="<?php echo $row->coordenador; ?>"> <br> <br>
        </div>
        <div>
            <label class='texto_editar'>E-mail Coordenador de Curso</label> <br>
            <input class='formulario_editar' type="text" name="email_coord_curso" value="<?php echo $row->email_coord_curso; ?>"> <br> <br>
        </div>
        <div>
            <button class='botao_cadastrar_curso' type="submit">Salvar</button>
        </div>
    </form>

</div>