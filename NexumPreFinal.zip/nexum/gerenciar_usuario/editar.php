<div class="gerenciar_usuarios_titulo">Editar Usuários</div>

<?php 
    // consulta aos dados do usuário
    $sql_usuario = "SELECT * FROM usuario 
            WHERE id_usuario=" . $_REQUEST["id"];

    $res_usuario = $conexao->query($sql_usuario);
    $row_usuario = $res_usuario->fetch_object();

    // consulta a tabela categoria
    $sql_categoria = "SELECT * FROM categoria
                ORDER BY id_categoria";

    $res_categoria = $conexao->query($sql_categoria);

    $qtd_categoria = $res_categoria->num_rows;
?>

<form action="?page=salvar&acao=editar" method="POST">
    <div class='quadrado_branco_cadastrar_usuarios'>
        <input type="hidden" name="id" value="<?php echo $row_usuario->id_usuario; ?>">
        <div class="centralizar_x">
            <br>
            <label class='texto_cadastrar'>Nome</label> <br>
            <input class='formulario_cadastrar' type="text" name="nome" value="<?php echo $row_usuario->nome;?>">
        </div> 
        <div class="centralizar_x">
            <br>
            <label class='texto_cadastrar'>E-Mail</label> <br>
            <input class='formulario_cadastrar' type="email" name="email" value="<?php echo $row_usuario->email;?>">
        </div class="centralizar_x"> 
        <br>
        <div class='container_opcoes_categoria' >
            <br>
            <?php 
                if($qtd_categoria>0){
                    echo "<label class='texto_cadastrar'>Categoria</label>";
                    echo "<div class='opcoes_categoria'>";
                        while($row_categoria=$res_categoria->fetch_object()){
                            if($row_categoria->id_categoria==$row_usuario->categoria){
                                echo "<input type=\"radio\" name=\"categoria\" value=\"".$row_categoria->id_categoria."\"checked>";
                                echo "<label for=\"categoria\">".$row_categoria->categoria."</label><br>";
                            }
                            else{
                                echo "<input type=\"radio\" name=\"categoria\" value=\"".$row_categoria->id_categoria."\">";
                                echo "<label for=\"categoria\">".$row_categoria->categoria."</label><br>";
                            }
                            
                        
                        }
                    echo "</div>";
                
                }
            ?>
        
        <br> 

        <div class="centralizar_x">
            <button class='botao_adicionar_usuario_pg_usuario' type="submit">Salvar</button>
        </div>
        <br>

        </div> 
        
    </div>
</form>