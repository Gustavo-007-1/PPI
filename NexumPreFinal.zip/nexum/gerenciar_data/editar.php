
<div class="quadado_branco_editar">
<div class='titulo_editar'>Editar evento</div> <br>

<?php 
    // consulta aos dados das datas
    $sql = "SELECT * FROM datas
            WHERE id_data=" . $_REQUEST["id_data"];

    $res= $conexao->query($sql);
    $row = $res->fetch_object();
?>


    <form action="?page=salvar&acao=editar&id_data=<?php echo $_REQUEST["id_data"];?>" method="POST">
        <div>
            <label class='parte_texto'>Nome</label> <br>
            <input type="text" name="nome" value="<?php echo $row->nome;?>"> <br> <br>
        </div>
        <div>
            <label class='parte_texto'>Data</label> <br>
            <input type="date" name="data" value="<?php echo $row->data;?>"> <br> <br>
        </div>
        <div>
            <label class='parte_texto'>Descrição<br></label>
            <textarea name="descricao"><?php echo $row->descricao;?></textarea> <br> <br>
        </div>
        <div>
            <button class='botao_salvar' type="submit">Salvar</button>
        </div>
    </form>

</div>