
<div class='titulo_principal'>Relatorio de Atividades</div>


<div class="quadrado_branco_cadastrar">

    <form enctype="multipart/form-data" action="?page=salvar&idusuario=<?php echo $_SESSION["id_usuario"]?>" method="POST">
        <div>
            <br>
            <label class='parte_texto'>Arquivo do Relatório de Atividades</label>  <br>
            <input type='file' name="rel_ativ" required>
            <br> <br>
        </div>
        <div>
            <label class='parte_texto'>Semestre</label>  <br>
            <select name="semestre">
                <option value="1">1º Semestre</option>
                <option value="2">2º Semestre</option>
            </select>
            <br> <br>
        </div>
        <div>
            <label class='parte_texto'>Ano</label> <br>
            <input type="number" name="ano">
        </div>
        <br>
        <?php  
            echo "<button class='botao_enviar_relatorio2' onclick=\"return confirm('Tem certeza que deseja enviar?')\">Enviar</button>";
        ?>
        <br> <br>
    </form>

</div>