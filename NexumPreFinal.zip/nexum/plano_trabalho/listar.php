<div class="quadrado_branco_listar">

<?php 

    if($_SESSION["categoria"]==3){
        // fazer aqui abaixo a consulta com os nomes dos arquivos para a disciplina em questão

        // consulta na disciplina
        $sql = "SELECT *
                FROM plano_trabalho
                WHERE id_professor=" . $_SESSION["id_usuario"];

        $res = $conexao->query($sql);
        $qtd = $res->num_rows;

        if($qtd>0){
            while($row= $res->fetch_object()){
                echo "<br><br><a class='divisao_plano' href=\"../plano_trabalho/".$row->arquivo."\" download=\"".$row->arquivo."\">".$row->arquivo."</a>";
            }
        }
        else{
            echo "Não há planos de trabalho enviados";
        }

    }
    else{
         // consulta na disciplina
         $sql = "SELECT *
         FROM plano_trabalho";

        $res = $conexao->query($sql);
        $qtd = $res->num_rows;

        if($qtd>0){
            while($row= $res->fetch_object()){
                echo "<br><br><a class='divisao_plano' href=\"../plano_trabalho/".$row->arquivo."\" download=\"".$row->arquivo."\">".$row->arquivo."</a>";
            }
        }
        else{
            echo "Não há planos de trabalho enviados";
        }
    }
?>

</div>
