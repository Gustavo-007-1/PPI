<?php
    switch($_REQUEST["acao"]){
        
        case 'cadastrar':
            // salvando imagem do parecer
            if (!empty($_FILES["imagem"]["name"])) {
                $imagem = $_FILES["imagem"];
                // Largura máxima em pixels
                $largura = 1500;
                // Altura máxima em pixels
                $altura = 1800;
                // Tamanho máximo do arquivo em bytes
                $tamanho = 10000000;
                //}
                $error = array();
        
        
                // Verifica se o arquivo é uma imagem
                if(!preg_match("/^image\/(webp|pjpeg|jpeg|png|gif|bmp)$/", $imagem["type"])){
                    $error[1] = "Isso não é uma imagem.";
                    } 
        
                // Pega as dimensões da imagem
                $dimensoes = getimagesize($imagem["tmp_name"]);
        
                // Verifica se a largura da imagem é maior que a largura permitida
                if($dimensoes[0] > $largura) {
                    $error[2] = "A largura da imagem não deve ultrapassar ".$largura." pixels";
                }
        
                // Verifica se a altura da imagem é maior que a altura permitida
                if($dimensoes[1] > $altura) {
                    $error[3] = "Altura da imagem não deve ultrapassar ".$altura." pixels";
                }
                
                // Verifica se o tamanho da imagem é maior que o tamanho permitido
                if($imagem["size"] > $tamanho) {
                        $error[4] = "A imagem deve ter no máximo ".$tamanho." bytes";
                }
        
                // Se não houver nenhum erro
                if (count($error) == 0) {
                
                // Pega extensão da imagem
                preg_match("/\.(gif|bmp|png|jpg|jpeg){1}$/i", $imagem["name"], $ext);
        
                // Gera um nome único para a imagem
                $nome_imagem = md5(uniqid(time())) . "." . $ext[1];
        
                // Caminho de onde ficará a imagem
                $caminho_imagem = "../gerenciar_parecer/imagem_parecer/" . $nome_imagem;
        
                // Faz o upload da imagem para seu respectivo caminho
                move_uploaded_file($imagem["tmp_name"], $caminho_imagem);
                }
            }
            else{
                $nome_imagem = NULL;
            }


            // salvando informações do parecer
            $texto_parecer = $_POST["texto_parecer"];
            $nome_diretor_ensino = $_POST["nome_diretor_ensino"];
            $email_diretor_ensino = $_POST["email_diretor_ensino"];
            $nome_coor_ensino = $_POST["nome_coor_ensino"];
            $email_coor_ensino = $_POST["email_coor_ensino"];
            $nome_coor_cae = $_POST["nome_coor_cae"];
            $email_coor_cae = $_POST["email_coor_cae"];

            $sql = "INSERT INTO parecer (texto, imagem, nome_diretor_ensino, email_diretor_ensino, nome_coor_ensino, email_coor_ensino, nome_coor_cae, email_coor_cae) 
                    VALUES ('{$texto_parecer}', '{$nome_imagem}', '{$nome_diretor_ensino}', '{$email_diretor_ensino}','{$nome_coor_ensino}', '{$email_coor_ensino}', '{$nome_coor_cae}', '{$email_coor_cae}')";
            
            $res = $conexao->query($sql);

            if($res == true){
                echo "<script>alert('Cadastrado com sucesso!');</script>";
                echo "<script>location.href='?page=';</script>";
            }

            else{
                echo "<script>alert('Não foi possível cadastrar!');</script>";
                echo "<script>location.href='?page=';</script>";
            }
            break;
        
        case 'editar':
                $texto_parecer = $_POST["texto_parecer"];
                $nome_diretor_ensino = $_POST["nome_diretor_ensino"];
                $email_diretor_ensino = $_POST["email_diretor_ensino"];
                $nome_coor_ensino = $_POST["nome_coor_ensino"];
                $email_coor_ensino = $_POST["email_coor_ensino"];
                $nome_coor_cae = $_POST["nome_coor_cae"];
                $email_coor_cae = $_POST["email_coor_cae"];
                $imagem_antiga = $_POST["imagem_antiga"];
                $imagem_nova = $_FILES["imagem_nova"];
                $imagem = $_FILES["imagem"];
    
                if (!empty($imagem_nova["name"])) {
                
                    // Largura máxima em pixels
                    $largura = 1500;
                    // Altura máxima em pixels
                    $altura = 1800;
                    // Tamanho máximo do arquivo em bytes
                    $tamanho = 10000000;
                    //}
                    $error = array();
            
            
                    // Verifica se o arquivo é uma imagem
                    if(!preg_match("/^image\/(webp|pjpeg|jpeg|png|gif|bmp)$/", $imagem_nova["type"])){
                        $error[1] = "Isso não é uma imagem.";
                        } 
            
                    // Pega as dimensões da imagem
                    $dimensoes = getimagesize($imagem_nova["tmp_name"]);
            
                    // Verifica se a largura da imagem é maior que a largura permitida
                    if($dimensoes[0] > $largura) {
                        $error[2] = "A largura da imagem não deve ultrapassar ".$largura." pixels";
                    }
            
                    // Verifica se a altura da imagem é maior que a altura permitida
                    if($dimensoes[1] > $altura) {
                        $error[3] = "Altura da imagem não deve ultrapassar ".$altura." pixels";
                    }
                    
                    // Verifica se o tamanho da imagem é maior que o tamanho permitido
                    if($imagem_nova["size"] > $tamanho) {
                            $error[4] = "A imagem deve ter no máximo ".$tamanho." bytes";
                    }
            
                    // Se não houver nenhum erro
                    if (count($error) == 0) {
                    
                    // Pega extensão da imagem
                    preg_match("/\.(gif|bmp|png|jpg|jpeg){1}$/i", $imagem_nova["name"], $ext);
            
                    // Gera um nome único para a imagem
                    $nome_imagem = md5(uniqid(time())) . "." . $ext[1];
            
                    // Caminho de onde ficará a imagem
                    $caminho_imagem = "../gerenciar_parecer/imagem_parecer/" . $nome_imagem;
            
                    // Faz o upload da imagem para seu respectivo caminho
                    move_uploaded_file($imagem_nova["tmp_name"], $caminho_imagem);
                    }
                }
    
                else if (!empty($imagem["name"])) {
                
                    // Largura máxima em pixels
                    $largura = 1500;
                    // Altura máxima em pixels
                    $altura = 1800;
                    // Tamanho máximo do arquivo em bytes
                    $tamanho = 10000000;
                    //}
                    $error = array();
            
            
                    // Verifica se o arquivo é uma imagem
                    if(!preg_match("/^image\/(webp|pjpeg|jpeg|png|gif|bmp)$/", $imagem["type"])){
                        $error[1] = "Isso não é uma imagem.";
                        } 
            
                    // Pega as dimensões da imagem
                    $dimensoes = getimagesize($imagem["tmp_name"]);
            
                    // Verifica se a largura da imagem é maior que a largura permitida
                    if($dimensoes[0] > $largura) {
                        $error[2] = "A largura da imagem não deve ultrapassar ".$largura." pixels";
                    }
            
                    // Verifica se a altura da imagem é maior que a altura permitida
                    if($dimensoes[1] > $altura) {
                        $error[3] = "Altura da imagem não deve ultrapassar ".$altura." pixels";
                    }
                    
                    // Verifica se o tamanho da imagem é maior que o tamanho permitido
                    if($imagem["size"] > $tamanho) {
                            $error[4] = "A imagem deve ter no máximo ".$tamanho." bytes";
                    }
            
                    // Se não houver nenhum erro
                    if (count($error) == 0) {
                    
                    // Pega extensão da imagem
                    preg_match("/\.(gif|bmp|png|jpg|jpeg){1}$/i", $imagem["name"], $ext);
            
                    // Gera um nome único para a imagem
                    $nome_imagem = md5(uniqid(time())) . "." . $ext[1];
            
                    // Caminho de onde ficará a imagem
                    $caminho_imagem = "../gerenciar_parecer/imagem_parecer/" . $nome_imagem;
            
                    // Faz o upload da imagem para seu respectivo caminho
                    move_uploaded_file($imagem["tmp_name"], $caminho_imagem);
                    }
                }
            
                else{	
                    $nome_imagem = $imagem_antiga;
                    //echo $imgantiga;
                }
    
                
                $sql = "UPDATE parecer
                        SET
                            texto = '{$texto_parecer}',
                            imagem = '{$nome_imagem}',
                            nome_diretor_ensino = '{$nome_diretor_ensino}',
                            email_diretor_ensino = '{$email_diretor_ensino}',
                            nome_coor_ensino = '{$nome_coor_ensino}',
                            email_coor_ensino = '{$email_coor_ensino}',
                            nome_coor_cae = '{$nome_coor_cae}',
                            email_coor_cae = '{$email_coor_cae}'
    
                        WHERE id_parecer=" . $_REQUEST["idparecer"];
    
                $res = $conexao->query($sql);
                
                if($res == true){
                    echo "<script>alert('Editado com sucesso!');</script>";
                    echo "<script>location.href='?page=';</script>";
                }
    
                else{
                    echo "<script>alert('Não foi possível editar!');</script>";
                    echo "<script>location.href='?page=';</script>";
                }
                break;

        case 'excluir':
            $sql = "SELECT imagem FROM parecer";
            $res = $conexao->query($sql);
            $row = $res->fetch_object();

            unlink("../gerenciar_parecer/imagem_parecer/".$row->imagem);
            
            $sql = "DELETE FROM parecer WHERE id_parecer = " . $_REQUEST["idparecer"];
            $res = $conexao->query($sql);

            if($res == true){
                echo "<script>alert('Excluído com sucesso!');</script>";
                echo "<script>location.href='?page=';</script>";
            }

            else{
                echo "<script>alert('Não foi possível excluir!');</script>";
                echo "<script>location.href='?page=';</script>";
            }
            break;
    }
?>