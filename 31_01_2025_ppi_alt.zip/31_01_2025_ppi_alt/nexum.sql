-- phpMyAdmin SQL Dump
-- version 5.0.1
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Tempo de geração: 01-Fev-2025 às 01:43
-- Versão do servidor: 5.6.34
-- versão do PHP: 7.4.3

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Banco de dados: `nexum`
--

-- --------------------------------------------------------

--
-- Estrutura da tabela `aluno`
--

CREATE TABLE `aluno` (
  `id_aluno` int(11) NOT NULL,
  `nome` varchar(200) NOT NULL,
  `numero_matricula` int(11) NOT NULL,
  `email_institucional` varchar(200) NOT NULL,
  `genero` varchar(20) DEFAULT NULL,
  `cidade` varchar(100) NOT NULL,
  `data_nascimento` date NOT NULL,
  `unidade_federativa` varchar(2) NOT NULL,
  `moradia` varchar(5) NOT NULL,
  `quant_reprovacao` int(11) NOT NULL,
  `acompanhamento_aee` varchar(45) DEFAULT NULL,
  `acompanhamento_cai` varchar(45) DEFAULT NULL,
  `acompanhamento_saude` varchar(45) DEFAULT NULL,
  `cota` int(11) DEFAULT NULL,
  `auxilio_permanencia` varchar(15) DEFAULT NULL,
  `apoio_psicologico` varchar(15) DEFAULT NULL,
  `projeto_extensao` varchar(50) DEFAULT NULL,
  `projeto_pesquisa` varchar(50) DEFAULT NULL,
  `projeto_ensino` varchar(50) DEFAULT NULL,
  `estagio` varchar(50) DEFAULT NULL,
  `equip_emprest` varchar(200) DEFAULT NULL,
  `foto` varchar(255) DEFAULT NULL,
  `id_turma` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Extraindo dados da tabela `aluno`
--

INSERT INTO `aluno` (`id_aluno`, `nome`, `numero_matricula`, `email_institucional`, `genero`, `cidade`, `data_nascimento`, `unidade_federativa`, `moradia`, `quant_reprovacao`, `acompanhamento_aee`, `acompanhamento_cai`, `acompanhamento_saude`, `cota`, `auxilio_permanencia`, `apoio_psicologico`, `projeto_extensao`, `projeto_pesquisa`, `projeto_ensino`, `estagio`, `equip_emprest`, `foto`, `id_turma`) VALUES
(11, 'isadora', 2022303410, 'isadora.2022303410@aluno.iffar.edu.br', '', 'constantina', '2007-03-02', 'RS', 'A09', 0, '', '', '', 0, '', '', '', '', '', '', '', '556cfd994eed6bb79d43a7156bcf667f.jpeg', 3),
(14, '', 0, '', NULL, '', '0000-00-00', '', '', 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', 4),
(16, 'Gustavo', 123321123, '', '', '', '2013-01-28', '', '', 0, '', '', '', 0, '', '', '', '', '', '', '', 'd4ab604f173b8a2cc3e1958770f79404.JPEG', 6),
(17, 'Marcia Andrada', 1232232211, 'marcia@iffarroupilha.com', NULL, 'Teresina', '2000-03-12', 'PI', 'NÃ£o', 2, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', 6);

-- --------------------------------------------------------

--
-- Estrutura da tabela `aluno_disciplina`
--

CREATE TABLE `aluno_disciplina` (
  `id_aluno_disciplina` int(11) NOT NULL,
  `id_aluno` int(11) NOT NULL,
  `id_disciplina` int(11) NOT NULL,
  `falta` int(11) DEFAULT NULL,
  `observacao` varchar(350) DEFAULT NULL,
  `nota_parcial_um` decimal(11,0) NOT NULL,
  `nota_primeiro_semestre` decimal(10,0) NOT NULL,
  `nota_parcial_dois` decimal(10,0) NOT NULL,
  `nota_segundo_semestre` decimal(10,0) NOT NULL,
  `ais` decimal(10,0) NOT NULL,
  `mc` decimal(10,0) NOT NULL,
  `ppi` decimal(10,0) NOT NULL,
  `media_anual` decimal(10,0) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Extraindo dados da tabela `aluno_disciplina`
--

INSERT INTO `aluno_disciplina` (`id_aluno_disciplina`, `id_aluno`, `id_disciplina`, `falta`, `observacao`, `nota_parcial_um`, `nota_primeiro_semestre`, `nota_parcial_dois`, `nota_segundo_semestre`, `ais`, `mc`, `ppi`, `media_anual`) VALUES
(1, 16, 9, NULL, 'Segundo melhor aluno', '3', '6', '2', '7', '10', '2', '2', '7'),
(2, 17, 9, NULL, 'Calma', '7', '2', '0', '0', '0', '0', '0', '1'),
(3, 17, 11, NULL, NULL, '0', '0', '0', '0', '0', '0', '0', '0'),
(4, 17, 13, 8, NULL, '0', '0', '0', '0', '0', '0', '7', '0'),
(6, 11, 17, NULL, NULL, '0', '0', '0', '0', '0', '0', '0', '0');

-- --------------------------------------------------------

--
-- Estrutura da tabela `ano`
--

CREATE TABLE `ano` (
  `id_ano` int(11) NOT NULL,
  `ano` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Extraindo dados da tabela `ano`
--

INSERT INTO `ano` (`id_ano`, `ano`) VALUES
(1, 1),
(2, 2),
(3, 3);

-- --------------------------------------------------------

--
-- Estrutura da tabela `categoria`
--

CREATE TABLE `categoria` (
  `id_categoria` int(11) NOT NULL,
  `categoria` varchar(45) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Extraindo dados da tabela `categoria`
--

INSERT INTO `categoria` (`id_categoria`, `categoria`) VALUES
(1, 'Administrador'),
(2, 'Setor de Apoio Pedagogico'),
(3, 'Professor'),
(4, 'Setores');

-- --------------------------------------------------------

--
-- Estrutura da tabela `curso`
--

CREATE TABLE `curso` (
  `id_curso` int(11) NOT NULL,
  `nome` varchar(100) NOT NULL,
  `carga_horaria` int(11) NOT NULL,
  `coordenador` varchar(200) NOT NULL,
  `email_coord_curso` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Extraindo dados da tabela `curso`
--

INSERT INTO `curso` (`id_curso`, `nome`, `carga_horaria`, `coordenador`, `email_coord_curso`) VALUES
(2, 'TÃ©cnico em InformÃ¡tica', 1234, 'George', ''),
(4, 'TÃ©cnico em AdministraÃ§Ã£o', 123, 'José', '');

-- --------------------------------------------------------

--
-- Estrutura da tabela `datas`
--

CREATE TABLE `datas` (
  `id_data` int(11) NOT NULL,
  `data` date NOT NULL,
  `nome` varchar(100) NOT NULL,
  `descricao` varchar(350) NOT NULL,
  `id_usuario` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estrutura da tabela `disciplina`
--

CREATE TABLE `disciplina` (
  `id_disciplina` int(11) NOT NULL,
  `nome` varchar(55) NOT NULL,
  `quant_periodos` int(11) NOT NULL,
  `recuperacao_paralela1` text,
  `recuperacao_paralela2` text,
  `id_turma` int(11) NOT NULL,
  `id_professor` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Extraindo dados da tabela `disciplina`
--

INSERT INTO `disciplina` (`id_disciplina`, `nome`, `quant_periodos`, `recuperacao_paralela1`, `recuperacao_paralela2`, `id_turma`, `id_professor`) VALUES
(9, 'FÃ­sica', 6, NULL, NULL, 6, 17),
(10, 'PortuguÃªs', 5, NULL, NULL, 4, 4),
(11, 'MatemÃ¡tica', 3, NULL, NULL, 6, 5),
(12, 'ProgramaÃ§Ã£o', 4, NULL, NULL, 1, 8),
(13, 'Direito', 2, 'recuperacao_paralela_35_Direito_primeiro_semestre.pdf', 'recuperacao_paralela_35_Direito_segundo_semestre.pdf', 6, 17),
(17, 'FÃ­sica', 2, NULL, NULL, 3, 17),
(18, 'HistÃ³ria', 2, NULL, NULL, 1, 18);

-- --------------------------------------------------------

--
-- Estrutura da tabela `observacoes`
--

CREATE TABLE `observacoes` (
  `id_observacao` int(11) NOT NULL,
  `observacao` varchar(300) NOT NULL,
  `id_turma` int(11) NOT NULL,
  `id_disciplina` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Extraindo dados da tabela `observacoes`
--

INSERT INTO `observacoes` (`id_observacao`, `observacao`, `id_turma`, `id_disciplina`) VALUES
(4, 'Concordo com o direito', 6, 9),
(5, 'Turma ta melhorando!', 6, 9);

-- --------------------------------------------------------

--
-- Estrutura da tabela `parecer`
--

CREATE TABLE `parecer` (
  `id_parecer` int(11) NOT NULL,
  `texto` longtext NOT NULL,
  `imagem` longtext NOT NULL,
  `nome_diretor_ensino` varchar(255) NOT NULL,
  `email_diretor_ensino` varchar(255) NOT NULL,
  `nome_coor_ensino` varchar(255) NOT NULL,
  `email_coor_ensino` varchar(255) NOT NULL,
  `nome_coor_cae` varchar(255) NOT NULL,
  `email_coor_cae` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Extraindo dados da tabela `parecer`
--

INSERT INTO `parecer` (`id_parecer`, `texto`, `imagem`, `nome_diretor_ensino`, `email_diretor_ensino`, `nome_coor_ensino`, `email_coor_ensino`, `nome_coor_cae`, `email_coor_cae`) VALUES
(1, 'sdddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddd', 'ee8225d4e1c5ce9ff1cadd219e6c67c4.jpeg', 'wfeer', 'asdasd@gmail.com', 'dwdwdd', 'aasshs@gmail', 'sdsdsdwd', 'gggggsshs@gmail');

-- --------------------------------------------------------

--
-- Estrutura da tabela `plano_trabalho`
--

CREATE TABLE `plano_trabalho` (
  `id_plano_trabalho` int(11) NOT NULL,
  `arquivo` varchar(255) NOT NULL,
  `ano` int(11) NOT NULL,
  `semestre` int(11) NOT NULL,
  `id_professor` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Extraindo dados da tabela `plano_trabalho`
--

INSERT INTO `plano_trabalho` (`id_plano_trabalho`, `arquivo`, `ano`, `semestre`, `id_professor`) VALUES
(3, '2023_plano_trabalho_Ademir_1_semestre.pdf', 2023, 1, 17);

-- --------------------------------------------------------

--
-- Estrutura da tabela `recuperacao_senha`
--

CREATE TABLE `recuperacao_senha` (
  `id` int(11) NOT NULL,
  `email` varchar(255) NOT NULL,
  `token` varchar(64) NOT NULL,
  `expira_em` datetime NOT NULL,
  `usado` tinyint(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Extraindo dados da tabela `recuperacao_senha`
--

INSERT INTO `recuperacao_senha` (`id`, `email`, `token`, `expira_em`, `usado`) VALUES
(1, 'xlsds41@gmail.com', '7b3b4be3cba187bf6e707ddc9c6bb3a3e050563317bbff23f82896279e094797', '2025-02-01 02:38:11', 0),
(2, 'xlsds41@gmail.com', '237afe66ebb4b324104740308a5dec22d0f932ee54d1882d9acb757c79459cbd', '2025-02-01 02:38:13', 0),
(3, 'xlsds41@gmail.com', '2aee834e2a4e46b6a0382a1d06c3cfda2b84d72311a9c0ab160f3e98a836269f', '2025-02-01 02:41:41', 0);

-- --------------------------------------------------------

--
-- Estrutura da tabela `relatorio_atividades`
--

CREATE TABLE `relatorio_atividades` (
  `id_relatorio` int(11) NOT NULL,
  `arquivo` varchar(255) NOT NULL,
  `ano` int(11) NOT NULL,
  `semestre` int(11) NOT NULL,
  `id_professor` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Extraindo dados da tabela `relatorio_atividades`
--

INSERT INTO `relatorio_atividades` (`id_relatorio`, `arquivo`, `ano`, `semestre`, `id_professor`) VALUES
(2, '2023_relatorio_atividade_Ademir_1_semestre.pdf', 2023, 1, 17);

-- --------------------------------------------------------

--
-- Estrutura da tabela `turma`
--

CREATE TABLE `turma` (
  `id_turma` int(11) NOT NULL,
  `numero` int(11) NOT NULL,
  `ano` int(11) NOT NULL,
  `conselheiro` int(11) DEFAULT NULL,
  `id_curso` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Extraindo dados da tabela `turma`
--

INSERT INTO `turma` (`id_turma`, `numero`, `ano`, `conselheiro`, `id_curso`) VALUES
(1, 24, 2, NULL, 2),
(4, 33, 3, NULL, 3),
(5, 14, 1, NULL, 2),
(6, 35, 3, NULL, 4),
(7, 16, 1, NULL, 2);

-- --------------------------------------------------------

--
-- Estrutura da tabela `usuario`
--

CREATE TABLE `usuario` (
  `id_usuario` int(11) NOT NULL,
  `nome` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `senha` varchar(255) NOT NULL,
  `categoria` int(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Extraindo dados da tabela `usuario`
--

INSERT INTO `usuario` (`id_usuario`, `nome`, `email`, `senha`, `categoria`) VALUES
(10, 'adm2', 'adm@gmail.com', '$2y$10$hh74ma2tInBMt3qTIT8vnOROOas9wdPOyJPy4JBsHW8vIVufX1RZW', 1),
(11, 'Marco', 'marco@teste.com', '$2y$10$dodA/QByJbPyLcQcevTAYORZaL/85zEEXwbPzXOK1/JqhLUje2jaC', 3),
(12, 'Mariana dos Santos', 'marianasantos@email.com', '$2y$10$Q1rbSEXFFCAdPdEaI7/bvOUUuYkqaunoumqCNL4.2qq3Slvq14ZkO', 3),
(15, 'adm200', 'xlsds41@gmail.com', '$2y$10$KtHwELRiyy.u6Flu31afUuX4YVKeIwqRZMvfs3M5HLadp9j/m4j1m', 1),
(17, 'Ademir', 'r.e24t9huqf.n8@gmail.com', '$2y$10$6CUGFKhuh5RtMg607FyDYOl4Eu9kx1z2alqC.pA9l3n3MNKRrcPnq', 3),
(19, 'PatrÃ­cia', 'patricia.2022319911@aluno.iffar.edu.br', '$2y$10$DKDL9/VgL3IQy/3olnzFIe/OySxnliw3CeeXSeHKQmlXkZJkaUvKW', 1);

--
-- Índices para tabelas despejadas
--

--
-- Índices para tabela `aluno`
--
ALTER TABLE `aluno`
  ADD PRIMARY KEY (`id_aluno`);

--
-- Índices para tabela `aluno_disciplina`
--
ALTER TABLE `aluno_disciplina`
  ADD PRIMARY KEY (`id_aluno_disciplina`);

--
-- Índices para tabela `ano`
--
ALTER TABLE `ano`
  ADD PRIMARY KEY (`id_ano`);

--
-- Índices para tabela `categoria`
--
ALTER TABLE `categoria`
  ADD PRIMARY KEY (`id_categoria`);

--
-- Índices para tabela `curso`
--
ALTER TABLE `curso`
  ADD PRIMARY KEY (`id_curso`);

--
-- Índices para tabela `datas`
--
ALTER TABLE `datas`
  ADD PRIMARY KEY (`id_data`);

--
-- Índices para tabela `disciplina`
--
ALTER TABLE `disciplina`
  ADD PRIMARY KEY (`id_disciplina`);

--
-- Índices para tabela `observacoes`
--
ALTER TABLE `observacoes`
  ADD PRIMARY KEY (`id_observacao`);

--
-- Índices para tabela `parecer`
--
ALTER TABLE `parecer`
  ADD PRIMARY KEY (`id_parecer`);

--
-- Índices para tabela `plano_trabalho`
--
ALTER TABLE `plano_trabalho`
  ADD PRIMARY KEY (`id_plano_trabalho`);

--
-- Índices para tabela `recuperacao_senha`
--
ALTER TABLE `recuperacao_senha`
  ADD PRIMARY KEY (`id`);

--
-- Índices para tabela `relatorio_atividades`
--
ALTER TABLE `relatorio_atividades`
  ADD PRIMARY KEY (`id_relatorio`);

--
-- Índices para tabela `turma`
--
ALTER TABLE `turma`
  ADD PRIMARY KEY (`id_turma`);

--
-- Índices para tabela `usuario`
--
ALTER TABLE `usuario`
  ADD PRIMARY KEY (`id_usuario`);

--
-- AUTO_INCREMENT de tabelas despejadas
--

--
-- AUTO_INCREMENT de tabela `aluno`
--
ALTER TABLE `aluno`
  MODIFY `id_aluno` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;

--
-- AUTO_INCREMENT de tabela `aluno_disciplina`
--
ALTER TABLE `aluno_disciplina`
  MODIFY `id_aluno_disciplina` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT de tabela `ano`
--
ALTER TABLE `ano`
  MODIFY `id_ano` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT de tabela `categoria`
--
ALTER TABLE `categoria`
  MODIFY `id_categoria` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT de tabela `curso`
--
ALTER TABLE `curso`
  MODIFY `id_curso` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT de tabela `datas`
--
ALTER TABLE `datas`
  MODIFY `id_data` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de tabela `disciplina`
--
ALTER TABLE `disciplina`
  MODIFY `id_disciplina` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;

--
-- AUTO_INCREMENT de tabela `observacoes`
--
ALTER TABLE `observacoes`
  MODIFY `id_observacao` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT de tabela `parecer`
--
ALTER TABLE `parecer`
  MODIFY `id_parecer` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT de tabela `plano_trabalho`
--
ALTER TABLE `plano_trabalho`
  MODIFY `id_plano_trabalho` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT de tabela `recuperacao_senha`
--
ALTER TABLE `recuperacao_senha`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT de tabela `relatorio_atividades`
--
ALTER TABLE `relatorio_atividades`
  MODIFY `id_relatorio` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT de tabela `turma`
--
ALTER TABLE `turma`
  MODIFY `id_turma` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT de tabela `usuario`
--
ALTER TABLE `usuario`
  MODIFY `id_usuario` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
