<div class="container_notas2">
<h1>Notas</h1>

<?php 

    $sql = "SELECT aluno_disciplina.id_aluno_disciplina, aluno_disciplina.id_aluno, aluno.nome, aluno.id_aluno, aluno_disciplina.nota_parcial_um, aluno_disciplina.nota_primeiro_semestre, aluno_disciplina.nota_parcial_dois, aluno_disciplina.nota_segundo_semestre, aluno_disciplina.ais, aluno_disciplina.mc, aluno_disciplina.ppi, aluno_disciplina.id_disciplina, aluno_disciplina.falta
    FROM aluno_disciplina INNER JOIN aluno
    ON aluno_disciplina.id_aluno = aluno.id_aluno
    WHERE aluno_disciplina.id_disciplina = " . $_REQUEST["iddisciplina"];

    $res = $conexao->query($sql);
    $qtd = $res->num_rows;

    echo "<form action=\"?page=salvar_notas&idturma=".$_REQUEST["idturma"]."&iddisciplina=".$_REQUEST["iddisciplina"]."\" method=\"POST\">";

        if($qtd>0){
            echo "<table border=\"1\">";
                echo "<tr>";
                    echo "<td>Nome do Aluno</td>";
                    echo "<td>Nota Parcial - 1º Semestre</td>";
                    echo "<td>Nota Semestral - 1º Semestre</td>";
                    echo "<td>AIS</td>";
                    echo "<td>Nota Parcial - 2º Semestre</td>";
                    echo "<td>Nota Semestre - 2º Semestre</td>";
                    echo "<td>Mostra de Ciências</td>";
                    echo "<td>PPI</td>";
                    echo "<td>Faltas</td>";
                echo "<tr>";

                while($row = $res->fetch_object()){
                    echo "<tr>";
                        echo "<td>" . $row->nome . "</td>";
                        echo "<td><input type=\"number\" name=\"notas[". $row->id_aluno_disciplina ."][nota_parcial_um]\" value=\"" . $row->nota_parcial_um . "\" step=\"0.1\"></td>";
                        echo "<td><input type=\"number\" name=\"notas[". $row->id_aluno_disciplina ."][nota_primeiro_semestre]\" value=\"" . $row->nota_primeiro_semestre . "\" step=\"0.1\"></td>";
                        echo "<td><input type=\"number\" name=\"notas[". $row->id_aluno_disciplina ."][ais]\" value=\"" . $row->ais . "\" step=\"0.1\"></td>";
                        echo "<td><input type=\"number\" name=\"notas[". $row->id_aluno_disciplina ."][nota_parcial_dois]\" value=\"" . $row->nota_parcial_dois . "\" step=\"0.1\"></td>";
                        echo "<td><input type=\"number\" name=\"notas[". $row->id_aluno_disciplina ."][nota_segundo_semestre]\" value=\"" . $row->nota_segundo_semestre . "\" step=\"0.1\"></td>";
                        echo "<td><input type=\"number\" name=\"notas[". $row->id_aluno_disciplina ."][mc]\" value=\"" . $row->mc . "\" step=\"0.1\"></td>";
                        echo "<td><input type=\"number\" name=\"notas[". $row->id_aluno_disciplina ."][ppi]\" value=\"" . $row->ppi . "\" step=\"0.1\"></td>";
                        echo "<td><input type=\"number\" name=\"notas[". $row->id_aluno_disciplina ."][falta]\" value=\"" . $row->falta . "\" step=\"0.1\"></td>";
                    echo "</tr>";
                }
                
            echo "</table>";
        }
        echo "<br>";
        echo "<button type=\"submit\">Salvar</button>";
    echo "</form>";

?>

</div>