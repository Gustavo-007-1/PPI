<h2>Relatório de Recuperação Paralela</h2>
<form enctype="multipart/form-data" action="?page=salvar_recup_para&idturma=<?php echo $_REQUEST["idturma"]?>&iddisciplina=<?php echo $_REQUEST["iddisciplina"]?>&nomedisciplina=<?php echo $_REQUEST["nomedisciplina"]?>&numeroturma=<?php echo $_REQUEST["numeroturma"]?>" method="POST">
    <div>
        <label>Relatório de Recuperação Paralela</label> 
        <input type='file' name="rel_recup_para" required>
        <br> <br>
    </div>
    <div>
        <label>Semestre</label> 
        <select name="semestre">
            <option value="primeiro">1º Semestre</option>
            <option value="segundo">2º Semestre</option>
        </select>
        <br> <br>
    </div>

    <?php 
        echo "<button onclick=\"return confirm('Tem certeza que deseja enviar?')\">Enviar</button>";
    ?>
</form>