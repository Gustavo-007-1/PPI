<div class='gerenciar_diciplinas_titulo'>Cadastrar Disciplina</div>
<?php
    #consulta a tabela turma
    $sql_turma = "SELECT id_turma, numero FROM turma
                ORDER BY numero";

    $res_turma = $conexao->query($sql_turma);
    $qtd_turma = $res_turma->num_rows;

    #consulta a tabela usuario
    $sql_usuario = "SELECT id_usuario, nome FROM usuario 
                    WHERE categoria = 3
                    ORDER BY nome ASC";

    $res_usuario = $conexao->query($sql_usuario);
    $qtd_usuario = $res_usuario->num_rows;

?>

<div class='quadrado_branco_cadastrar_diciplinas '>
<form action="?page=salvar&acao=cadastrar" method="POST">
    
    <div>
        <label class="texto_cadastrar">Disciplina</label> <br>
        <input type="text" name="disciplina" required> <br> <br>
    </div>

    <div>
        <label class="texto_cadastrar">Quantidade de Períodos</label> <br>
        <input type="number" name="quant_periodos" required> <br> <br>
    </div>

    <div>
        <label class="texto_cadastrar">Professor</label> <br>
        <select name="professor"> <br> <br> <br>
            <?php
                if($qtd_usuario>0){
                    while($row_usuario = $res_usuario->fetch_object()){
                        echo "<option value=\"". $row_usuario->id_usuario."\">". $row_usuario->nome ."</option>";
                    }
                }  
            ?>
        </select>
    </div>
    <br>
    <div>
        <label class="texto_cadastrar">Turma</label> <br>
        <?php
            if($qtd_turma>0){
                while($row_turma = $res_turma->fetch_object()){
                    echo "<input type=\"radio\" name=\"turma\" value=\"".$row_turma->id_turma."\">";
                    echo "<label for=\"turma\">T".$row_turma->numero."</label><br>";
                }
            }  
        ?>
    </div>
    <div>
        <button class='botao_cadastrar_definitivo' type="submit">Cadastrar</button>
    </div>
</form>
</div>