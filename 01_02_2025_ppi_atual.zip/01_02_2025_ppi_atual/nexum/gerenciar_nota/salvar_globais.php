<?php 
    if(($_SERVER["REQUEST_METHOD"] == "POST") && isset($_POST["notas"])){
        foreach ($_POST["notas"] as $id_aluno => $notas) {
            $ais = $notas["ais"];
            $mc = $notas["mc"];
            $ppi = $notas["ppi"];

            $sql = "UPDATE aluno SET
                ais = '{$ais}',
                mc = '{$mc}',
                ppi = '{$ppi}'
                WHERE id_aluno = $id_aluno";

            $conexao->query($sql);
        }
        echo "<script>alert('Editado com sucesso!');</script>";
        echo "<script>location.href='?page=notas_globais&idturma=".$_REQUEST["idturma"]."';</script>";
    }
?>