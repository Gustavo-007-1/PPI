<div class="container_notas">
<?php  
echo "<button onclick=\"location.href='?page=registrar_globais&idturma=" . $_REQUEST["idturma"] . "';\">Registrar Notas</button>";
?>

<h1>Notas Globais</h1>
<?php 

$sql = "SELECT aluno.nome, aluno.id_aluno, aluno.ais, aluno.mc, aluno.ppi
FROM aluno
WHERE aluno.id_turma = " . $_REQUEST["idturma"];

$res = $conexao->query($sql);
$qtd = $res->num_rows;

if($qtd>0){
    echo "<table border=\"1\">";
        echo "<tr>";
            echo "<td>Nome do Aluno</td>";
            echo "<td>AIS</td>";
            echo "<td>Mostra de Ciências</td>";
            echo "<td>PPI</td>";

        echo "<tr>";

        while($row = $res->fetch_object()){
            echo "<tr>";
                echo "<td>" . $row->nome . "</td>";
                echo "<td>" . $row->ais . "</td>";
                echo "<td>" . $row->mc . "</td>";
                echo "<td>" . $row->ppi . "</td>";  
            echo "</tr>";
        }
        
    echo "</table>";
}

?>

</div>