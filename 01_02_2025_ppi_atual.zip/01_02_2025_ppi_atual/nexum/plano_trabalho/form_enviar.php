<h2>Plano de Trabalho</h2>
<form enctype="multipart/form-data" action="?page=salvar&idusuario=<?php echo $_SESSION["id_usuario"]?>" method="POST">
    <div>
        <label>Arquivo do Plano de Trabalho</label> 
        <input type='file' name="rel_plano" required>
        <br> <br>
    </div>
    <div>
        <label>Semestre</label> 
        <select name="semestre">
            <option value="1">1º Semestre</option>
            <option value="2">2º Semestre</option>
        </select>
        <br> <br>
    </div>
    <div>
        <label>Ano</label>
        <input type="number" name="ano">
    </div>

    <?php 
        echo "<button onclick=\"return confirm('Tem certeza que deseja enviar?')\">Enviar</button>";
    ?>
</form>