<?php
// Inicia a sessão (se ainda não estiver iniciada)
session_start();

// Limpa todas as variáveis de sessão
$_SESSION = array();

// Destroi a sessão
session_destroy();

// Redireciona para a página de login, por exemplo
header("Location: index.php");
exit();
?>