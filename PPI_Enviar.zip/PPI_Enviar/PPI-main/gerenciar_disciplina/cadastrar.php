<h1>Cadastrar Disciplina</h1>
<?php
    #consulta a tabela turma
    $sql_turma = "SELECT id_turma, numero FROM turma
                ORDER BY numero";

    $res_turma = $conexao->query($sql_turma);
    $qtd_turma = $res_turma->num_rows;

    #consulta a tabela usuario
    $sql_usuario = "SELECT id_usuario, nome FROM usuario 
                    WHERE categoria = 3
                    ORDER BY nome ASC";

    $res_usuario = $conexao->query($sql_usuario);
    $qtd_usuario = $res_usuario->num_rows;

?>

<form action="?page=salvar&acao=cadastrar" method="POST">
    
    <div>
        <label>Disciplina</label>
        <input type="text" name="disciplina" required>
    </div>

    <div>
        <label>Quantidade de Períodos</label>
        <input type="number" name="quant_periodos" required>
    </div>

    <div>
        <label>Professor</label>
        <select name="professor">
            <?php
                if($qtd_usuario>0){
                    while($row_usuario = $res_usuario->fetch_object()){
                        echo "<option value=\"". $row_usuario->id_usuario."\">". $row_usuario->nome ."</option>";
                    }
                }  
            ?>
        </select>
    </div>

    <div>
        <label>Turma</label>
        <?php
            if($qtd_turma>0){
                while($row_turma = $res_turma->fetch_object()){
                    echo "<input type=\"radio\" name=\"turma\" value=\"".$row_turma->id_turma."\">";
                    echo "<label for=\"turma\">T".$row_turma->numero."</label><br>";
                }
            }  
        ?>
    </div>
    <div>
        <button type="submit">Cadastrar</button>
    </div>
</form>