<?php
    switch($_REQUEST["acao"]){
        
        case 'cadastrar':
            $nome = $_POST["nome"];
            $data = $_POST["data"];
            $descricao = $_POST["descricao"];
            $id_usuario = $_SESSION["id_usuario"];

            $sql = "INSERT INTO datas (data, nome, descricao, id_usuario) 
                    VALUES ('{$data}', '{$nome}', '{$descricao}', '{$id_usuario}')";
            
            $res = $conexao->query($sql);

            if($res == true){
                echo "<script>alert('Evento cadastrado com sucesso!');</script>";
                echo "<script>location.href='?page=';</script>";
            }

            else{
                echo "<script>alert('Não foi possível cadastrar o evento!');</script>";
                echo "<script>location.href='?page=';</script>";
            }
            break;
        
        case 'editar':
            $nome = $_POST["nome"];
            $data = $_POST["data"];
            $descricao = $_POST["descricao"];
            
            $sql = "UPDATE datas 
                    SET 
                        data = '{$data}',
                        nome = '{$nome}',
                        descricao = '{$descricao}'

                    WHERE id_data = " . $_REQUEST["id_data"];

            $res = $conexao->query($sql);

            if($res == true){
                echo "<script>alert('Editado com sucesso!');</script>";
                echo "<script>location.href='?page=';</script>";
            }

            else{
                echo "<script>alert('Não foi possível editar!');</script>";
                echo "<script>location.href='?page=';</script>";
            }
            

            break;

        case 'excluir':
            
            $sql = "DELETE FROM datas WHERE id_data = ".$_REQUEST["id_data"];
            
            $res = $conexao->query($sql);

            if($res == true){
                echo "<script>alert('Excluido com sucesso!');</script>";
                echo "<script>location.href='?page=';</script>";
            }

            else{
                echo "<script>alert('Não foi possível excluir!');</script>";
                echo "<script>location.href='?page=';</script>";
            }
            break;
    }

?>