<?php 
    $sql_observacao = "SELECT id_observacao, observacao FROM observacoes WHERE id_observacao=".$_REQUEST["idobservacao"];
    $res_observacao = $conexao->query($sql_observacao);
    $row_observacao = $res_observacao->fetch_object();
?>

<h1>Editar Observação</h1>
<form action="?page=salvar_observacoes_turma&acao=editar&idturma=<?php echo $_REQUEST["idturma"];?>&iddisciplina=<?php echo $_REQUEST["iddisciplina"];?>&idobservacao=<?php echo $_REQUEST["idobservacao"];?>" method="POST">
    <div>
        <label>Observação</label>
        <textarea name="observacao"><?php echo $row_observacao->observacao;?></textarea>
    </div>
    <div>
        <button type="submit">Salvar</button>
    </div>
</form>