
<?php 
    include("config.php");

    $email = $_POST["email"];
    $senha_confirmar = $_POST["senha_confirmar"];
    $senha_nova = $_POST["senha_nova"];

    if($senha_confirmar == $senha_nova){
        $nova_senha = password_hash($senha_nova, PASSWORD_DEFAULT);
        $sql = "UPDATE usuario
                SET senha = '{$nova_senha}'
                WHERE email = '{$email}'";

        $res = $conexao->query($sql);

        if($res == true){
            echo "<script>alert('Senha alterada com sucesso!');</script>";
            echo "<script>location.href='./index.php';</script>";
        }

        else{
            echo "<script>alert('Não foi possível alterar a senha!');</script>";
            echo "<script>location.href='./index.php';</script>";
        }
    }
    else if($senha_nova != $senha_confirmar){
        echo "<script>alert('As senhas são diferentes!');</script>";
        echo "<script>location.href='recuperar_senha_form.php';</script>";
    }
?>