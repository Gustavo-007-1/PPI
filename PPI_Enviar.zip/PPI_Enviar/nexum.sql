-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Tempo de geração: 26/11/2024 às 20:29
-- Versão do servidor: 10.4.28-MariaDB
-- Versão do PHP: 8.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Banco de dados: `nexum`
--

-- --------------------------------------------------------

--
-- Estrutura para tabela `aluno`
--

CREATE TABLE `aluno` (
  `id_aluno` int(11) NOT NULL,
  `nome` varchar(200) NOT NULL,
  `numero_matricula` int(11) NOT NULL,
  `email_institucional` varchar(200) NOT NULL,
  `genero` varchar(20) DEFAULT NULL,
  `cidade` varchar(100) NOT NULL,
  `data_nascimento` date NOT NULL,
  `unidade_federativa` varchar(2) NOT NULL,
  `moradia` varchar(5) NOT NULL,
  `quant_reprovacao` int(11) NOT NULL,
  `acompanhamento_aee` varchar(45) DEFAULT NULL,
  `acompanhamento_cai` varchar(45) DEFAULT NULL,
  `acompanhamento_saude` varchar(45) DEFAULT NULL,
  `cota` int(11) DEFAULT NULL,
  `auxilio_permanencia` varchar(15) DEFAULT NULL,
  `apoio_psicologico` varchar(15) DEFAULT NULL,
  `projeto_extensao` varchar(50) DEFAULT NULL,
  `projeto_pesquisa` varchar(50) DEFAULT NULL,
  `projeto_ensino` varchar(50) DEFAULT NULL,
  `estagio` varchar(50) DEFAULT NULL,
  `equip_emprest` varchar(200) DEFAULT NULL,
  `foto` varchar(255) DEFAULT NULL,
  `id_turma` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- Despejando dados para a tabela `aluno`
--

INSERT INTO `aluno` (`id_aluno`, `nome`, `numero_matricula`, `email_institucional`, `genero`, `cidade`, `data_nascimento`, `unidade_federativa`, `moradia`, `quant_reprovacao`, `acompanhamento_aee`, `acompanhamento_cai`, `acompanhamento_saude`, `cota`, `auxilio_permanencia`, `apoio_psicologico`, `projeto_extensao`, `projeto_pesquisa`, `projeto_ensino`, `estagio`, `equip_emprest`, `foto`, `id_turma`) VALUES
(11, 'isadora', 2022303410, 'isadora.2022303410@aluno.iffar.edu.br', '', 'constantina', '2007-03-02', 'RS', 'A09', 0, '', '', '', 0, '', '', '', '', '', '', '', '556cfd994eed6bb79d43a7156bcf667f.jpeg', 3),
(14, '', 0, '', NULL, '', '0000-00-00', '', '', 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', 4),
(17, 'Marcia Andrada', 1232232211, 'marcia@iffarroupilha.com', NULL, 'Teresina', '2000-03-12', 'PI', 'NÃ£o', 2, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', 6),
(18, 'Marcão', 12, '123@123', NULL, 'es', '2024-10-30', '1', '321', 123, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', 7);

-- --------------------------------------------------------

--
-- Estrutura para tabela `aluno_disciplina`
--

CREATE TABLE `aluno_disciplina` (
  `id_aluno_disciplina` int(11) NOT NULL,
  `id_aluno` int(11) NOT NULL,
  `id_disciplina` int(11) NOT NULL,
  `falta` int(11) DEFAULT NULL,
  `observacao` varchar(350) DEFAULT NULL,
  `nota_parcial_um` decimal(11,0) NOT NULL,
  `nota_primeiro_semestre` decimal(10,0) NOT NULL,
  `nota_parcial_dois` decimal(10,0) NOT NULL,
  `nota_segundo_semestre` decimal(10,0) NOT NULL,
  `ais` decimal(10,0) NOT NULL,
  `mc` decimal(10,0) NOT NULL,
  `ppi` decimal(10,0) NOT NULL,
  `media_anual` decimal(10,0) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- Despejando dados para a tabela `aluno_disciplina`
--

INSERT INTO `aluno_disciplina` (`id_aluno_disciplina`, `id_aluno`, `id_disciplina`, `falta`, `observacao`, `nota_parcial_um`, `nota_primeiro_semestre`, `nota_parcial_dois`, `nota_segundo_semestre`, `ais`, `mc`, `ppi`, `media_anual`) VALUES
(2, 17, 9, NULL, 'Calma', 0, 0, 0, 0, 0, 0, 0, 0),
(3, 17, 11, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0),
(4, 17, 13, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0),
(6, 11, 17, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0),
(7, 18, 12, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0);

-- --------------------------------------------------------

--
-- Estrutura para tabela `ano`
--

CREATE TABLE `ano` (
  `id_ano` int(11) NOT NULL,
  `ano` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- Despejando dados para a tabela `ano`
--

INSERT INTO `ano` (`id_ano`, `ano`) VALUES
(1, 1),
(2, 2),
(3, 3);

-- --------------------------------------------------------

--
-- Estrutura para tabela `categoria`
--

CREATE TABLE `categoria` (
  `id_categoria` int(11) NOT NULL,
  `categoria` varchar(45) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- Despejando dados para a tabela `categoria`
--

INSERT INTO `categoria` (`id_categoria`, `categoria`) VALUES
(1, 'Administrador'),
(2, 'Setor de Apoio Pedagogico'),
(3, 'Professor'),
(4, 'Setores');

-- --------------------------------------------------------

--
-- Estrutura para tabela `curso`
--

CREATE TABLE `curso` (
  `id_curso` int(11) NOT NULL,
  `nome` varchar(100) NOT NULL,
  `carga_horaria` int(11) NOT NULL,
  `coordenador` varchar(200) NOT NULL,
  `email_coord_curso` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- Despejando dados para a tabela `curso`
--

INSERT INTO `curso` (`id_curso`, `nome`, `carga_horaria`, `coordenador`, `email_coord_curso`) VALUES
(2, 'TÃ©cnico em InformÃ¡tica', 1234, 'George', ''),
(4, 'TÃ©cnico em AdministraÃ§Ã£o', 123, 'JoÂ´se ', '');

-- --------------------------------------------------------

--
-- Estrutura para tabela `datas`
--

CREATE TABLE `datas` (
  `id_data` int(11) NOT NULL,
  `data` date NOT NULL,
  `nome` varchar(100) NOT NULL,
  `descricao` varchar(350) NOT NULL,
  `id_usuario` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- Despejando dados para a tabela `datas`
--

INSERT INTO `datas` (`id_data`, `data`, `nome`, `descricao`, `id_usuario`) VALUES
(1, '2024-10-31', 'a', 'a', 10);

-- --------------------------------------------------------

--
-- Estrutura para tabela `disciplina`
--

CREATE TABLE `disciplina` (
  `id_disciplina` int(11) NOT NULL,
  `nome` varchar(55) NOT NULL,
  `quant_periodos` int(11) NOT NULL,
  `recuperacao_paralela1` text DEFAULT NULL,
  `recuperacao_paralela2` text DEFAULT NULL,
  `id_turma` int(11) NOT NULL,
  `id_professor` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- Despejando dados para a tabela `disciplina`
--

INSERT INTO `disciplina` (`id_disciplina`, `nome`, `quant_periodos`, `recuperacao_paralela1`, `recuperacao_paralela2`, `id_turma`, `id_professor`) VALUES
(9, 'FÃ­sica', 6, NULL, NULL, 6, 17),
(10, 'PortuguÃªs', 5, NULL, NULL, 4, 11),
(11, 'MatemÃ¡tica', 3, NULL, NULL, 6, 5),
(12, 'ProgramaÃ§Ã£o', 4, NULL, NULL, 7, 11),
(13, 'Direito', 2, NULL, NULL, 6, 17),
(17, 'FÃ­sica', 2, NULL, NULL, 3, 11);

-- --------------------------------------------------------

--
-- Estrutura para tabela `observacoes`
--

CREATE TABLE `observacoes` (
  `id_observacao` int(11) NOT NULL,
  `observacao` varchar(300) NOT NULL,
  `id_turma` int(11) NOT NULL,
  `id_disciplina` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- Despejando dados para a tabela `observacoes`
--

INSERT INTO `observacoes` (`id_observacao`, `observacao`, `id_turma`, `id_disciplina`) VALUES
(1, 'Bonita e em conta', 6, 13);

-- --------------------------------------------------------

--
-- Estrutura para tabela `parecer`
--

CREATE TABLE `parecer` (
  `id_parecer` int(11) NOT NULL,
  `texto` longtext NOT NULL,
  `imagem` longtext NOT NULL,
  `nome_diretor_ensino` varchar(255) NOT NULL,
  `email_diretor_ensino` varchar(255) NOT NULL,
  `nome_coor_ensino` varchar(255) NOT NULL,
  `email_coor_ensino` varchar(255) NOT NULL,
  `nome_coor_cae` varchar(255) NOT NULL,
  `email_coor_cae` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- Despejando dados para a tabela `parecer`
--

INSERT INTO `parecer` (`id_parecer`, `texto`, `imagem`, `nome_diretor_ensino`, `email_diretor_ensino`, `nome_coor_ensino`, `email_coor_ensino`, `nome_coor_cae`, `email_coor_cae`) VALUES
(1, 'o cara é muito bom, nao tem como nao', '3223a9250dd1ac9ff6e5f93be9b033aa.png', 'marcao', 'email_direcao@a', 'coordenador_ensinoaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa', 'email_cordenador_ensini@a', 'coordenadoir', 'coordenadir@a');

-- --------------------------------------------------------

--
-- Estrutura para tabela `turma`
--

CREATE TABLE `turma` (
  `id_turma` int(11) NOT NULL,
  `numero` int(11) NOT NULL,
  `ano` int(11) NOT NULL,
  `conselheiro` int(11) DEFAULT NULL,
  `id_curso` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- Despejando dados para a tabela `turma`
--

INSERT INTO `turma` (`id_turma`, `numero`, `ano`, `conselheiro`, `id_curso`) VALUES
(1, 24, 2, NULL, 2),
(3, 34, 3, NULL, 2),
(4, 33, 3, NULL, 3),
(5, 14, 1, NULL, 2),
(6, 35, 3, NULL, 4),
(7, 16, 1, NULL, 2);

-- --------------------------------------------------------

--
-- Estrutura para tabela `usuario`
--

CREATE TABLE `usuario` (
  `id_usuario` int(11) NOT NULL,
  `nome` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `senha` varchar(255) NOT NULL,
  `categoria` int(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- Despejando dados para a tabela `usuario`
--

INSERT INTO `usuario` (`id_usuario`, `nome`, `email`, `senha`, `categoria`) VALUES
(10, 'adm2', 'adm@gmail.com', '$2y$10$Fcl6/xk/2rMVqTTbdwN9cOmf/4caGYhHSjbhbvVGkIAZwGIX.N2SW', 1),
(15, 'adm200', 'xlsds41@gmail.com', '$2y$10$tUstNA0VgsA2Lhk3q.FT6elW1tP4jEuLHpnFcMwUppS0hGFmJJrli', 1),
(18, 'teste butao', 'testebutao@a', 'cd045fa3', 3),
(19, 'Tecnico agrario', '123@123', 'a460dced', 3);

--
-- Índices para tabelas despejadas
--

--
-- Índices de tabela `aluno`
--
ALTER TABLE `aluno`
  ADD PRIMARY KEY (`id_aluno`);

--
-- Índices de tabela `aluno_disciplina`
--
ALTER TABLE `aluno_disciplina`
  ADD PRIMARY KEY (`id_aluno_disciplina`);

--
-- Índices de tabela `ano`
--
ALTER TABLE `ano`
  ADD PRIMARY KEY (`id_ano`);

--
-- Índices de tabela `categoria`
--
ALTER TABLE `categoria`
  ADD PRIMARY KEY (`id_categoria`);

--
-- Índices de tabela `curso`
--
ALTER TABLE `curso`
  ADD PRIMARY KEY (`id_curso`);

--
-- Índices de tabela `datas`
--
ALTER TABLE `datas`
  ADD PRIMARY KEY (`id_data`);

--
-- Índices de tabela `disciplina`
--
ALTER TABLE `disciplina`
  ADD PRIMARY KEY (`id_disciplina`);

--
-- Índices de tabela `observacoes`
--
ALTER TABLE `observacoes`
  ADD PRIMARY KEY (`id_observacao`);

--
-- Índices de tabela `parecer`
--
ALTER TABLE `parecer`
  ADD PRIMARY KEY (`id_parecer`);

--
-- Índices de tabela `turma`
--
ALTER TABLE `turma`
  ADD PRIMARY KEY (`id_turma`);

--
-- Índices de tabela `usuario`
--
ALTER TABLE `usuario`
  ADD PRIMARY KEY (`id_usuario`);

--
-- AUTO_INCREMENT para tabelas despejadas
--

--
-- AUTO_INCREMENT de tabela `aluno`
--
ALTER TABLE `aluno`
  MODIFY `id_aluno` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;

--
-- AUTO_INCREMENT de tabela `aluno_disciplina`
--
ALTER TABLE `aluno_disciplina`
  MODIFY `id_aluno_disciplina` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT de tabela `ano`
--
ALTER TABLE `ano`
  MODIFY `id_ano` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT de tabela `categoria`
--
ALTER TABLE `categoria`
  MODIFY `id_categoria` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT de tabela `curso`
--
ALTER TABLE `curso`
  MODIFY `id_curso` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT de tabela `datas`
--
ALTER TABLE `datas`
  MODIFY `id_data` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT de tabela `disciplina`
--
ALTER TABLE `disciplina`
  MODIFY `id_disciplina` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;

--
-- AUTO_INCREMENT de tabela `observacoes`
--
ALTER TABLE `observacoes`
  MODIFY `id_observacao` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT de tabela `parecer`
--
ALTER TABLE `parecer`
  MODIFY `id_parecer` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT de tabela `turma`
--
ALTER TABLE `turma`
  MODIFY `id_turma` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT de tabela `usuario`
--
ALTER TABLE `usuario`
  MODIFY `id_usuario` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
