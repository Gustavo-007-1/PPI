
<div class="container_notas">
<?php  
echo "<button onclick=\"location.href='?page=registrar_notas&idturma=" . $_REQUEST["idturma"] . "&iddisciplina=" . $_REQUEST["iddisciplina"] . "';\">Registrar Notas</button>"; 
?>

<h1>Notas</h1>
<?php 

$sql = "SELECT aluno_disciplina.id_aluno_disciplina, aluno_disciplina.id_aluno, aluno.nome, aluno.id_aluno, aluno_disciplina.nota_parcial_um, aluno_disciplina.nota_primeiro_semestre, aluno_disciplina.nota_parcial_dois, aluno_disciplina.nota_segundo_semestre, aluno_disciplina.ais, aluno_disciplina.mc, aluno_disciplina.ppi, aluno_disciplina.id_disciplina, aluno_disciplina.falta
FROM aluno_disciplina INNER JOIN aluno
ON aluno_disciplina.id_aluno = aluno.id_aluno
WHERE aluno_disciplina.id_disciplina = " . $_REQUEST["iddisciplina"];

$res = $conexao->query($sql);
$qtd = $res->num_rows;

if($qtd>0){
    echo "<table border=\"1\">";
        echo "<tr>";
            echo "<td>Nome do Aluno</td>";
            echo "<td>Nota Parcial - 1º Semestre</td>";
            echo "<td>Nota Semestral - 1º Semestre</td>";
            echo "<td>AIS</td>";
            echo "<td>Nota Parcial - 2º Semestre</td>";
            echo "<td>Nota Semestre - 2º Semestre</td>";
            echo "<td>Mostra de Ciências</td>";
            echo "<td>PPI</td>";
            echo "<td>Faltas</td>";
        echo "<tr>";

        while($row = $res->fetch_object()){
            echo "<tr>";
                echo "<td>" . $row->nome . "</td>";
                echo "<td>" . $row->nota_parcial_um . "</td>";
                echo "<td>" . $row->nota_primeiro_semestre. "</td>";
                echo "<td>" . $row->ais . "</td>";
                echo "<td>" . $row->nota_parcial_dois . "</td>";
                echo "<td>" . $row->nota_segundo_semestre . "</td>";
                echo "<td>" . $row->mc . "</td>";
                echo "<td>" . $row->ppi . "</td>";
                echo "<td>" . $row->falta . "</td>";    
            echo "</tr>";
        }
        
    echo "</table>";
}

?>

</div>