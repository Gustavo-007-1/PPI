<div class='cadastrar_curso_titulo'>Cadastrar Curso</div>

<div class='container_cadastro_curso'>

<form action="?page=salvar_curso&acao=cadastrar" method="POST">
    <div>
        <label class='texto_cadastrar1'>Nome</label> <br>
        <input class='formulario_cadastrar1' type="text" name="nome" required>
    </div>
    <div>
        <label class='texto_cadastrar2'>Carga Horária</label>
        <input class='formulario_cadastrar2' type="number" name="carga_horaria" required>
    </div>
    <div>
        <label class='texto_cadastrar3'>Coordenador de Curso</label>
        <input class='formulario_cadastrar3' type="text" name="coordenador">
    </div>
    <div>
        <label >E-mail Coordenador de Curso</label>
        <input type="text" name="email_coord_curso">
    </div>
    <div>
        <button class='botao_cadastrar_curso' type="submit">Cadastrar</button>
    </div>
</form>

</div>