</div ><div class='listar_observacoes_turma_titulo'>Observações Sobre o Aluno</div>

<div class="container_observacoes_turma">
<?php 
    // selecionar no banco as observações existentes e listá-las
    $sql_observacao = "SELECT aluno_disciplina.id_aluno_disciplina, aluno_disciplina.observacao, aluno_disciplina.id_disciplina, aluno_disciplina.id_aluno, disciplina.nome
                    FROM aluno_disciplina INNER JOIN disciplina
                    ON aluno_disciplina.id_disciplina = disciplina.id_disciplina
                    WHERE aluno_disciplina.id_aluno = " . $_REQUEST["idaluno"];

    $res_observacao = $conexao->query($sql_observacao);
    $qtd_observacao = $res_observacao->num_rows;         

    //opções de criar nova observação
    if($_SESSION["categoria"]==3){
        echo "<button class='botao_observacoes_turma_cadastrar_p ' onclick=\"location.href='?page=aluno&info=cadastrar_observacoes_aluno&idaluno=".  $_REQUEST["idaluno"] ."&idturma=" .  $_REQUEST["idturma"] . "&iddisciplina=" . $_REQUEST["iddisciplina"] . "';\">Cadastrar</button>";   
    }   

    // lista as observacoes existentes no bd
    echo "<div class='contaimer_comentario_geral'>";
        if($qtd_observacao>0){
            while ($row_observacao = $res_observacao->fetch_object()) {
                    echo "<div>";
                        if($row_observacao->observacao != NULL){

                            echo "<div class='linha_separa_usuario'>";
                            echo $row_observacao->nome . "<br>";
                            echo "</div>";

                            echo $row_observacao->observacao . "<br><br>";

                            if ($row_observacao->id_disciplina == $_REQUEST["iddisciplina"]) {

                                echo "<button class='botao_editar_observacao_turma' onclick=\"location.href='?page=aluno&info=editar_observacoes_aluno&idaluno=".  $_REQUEST["idaluno"] ."&idturma=".$_REQUEST["idturma"]."&iddisciplina=" . $row_observacao->id_disciplina ."&idalunodisciplina=".$row_observacao->id_aluno_disciplina."';\">Editar</button>";

                                echo " <button class='botao_excluir_observacao_turma' onclick=\"if(confirm('Tem certeza que deseja excluir?')){location.href='?page=aluno&info=salvar_observacoes_aluno&acao=excluir&idaluno=".  $_REQUEST["idaluno"] ."&idturma=".$_REQUEST["idturma"]."&iddisciplina=".$row_observacao->id_disciplina ."&idalunodisciplina==".$row_observacao->id_aluno_disciplina."';}else{false;}\"'>Excluir</button><br>";
                            }
                        }

                    echo "</div>";
            }
        }
    echo "</div>";
?>

<script>

document.addEventListener("DOMContentLoaded", () => {
    const container = document.querySelector('.container_info_aluno');

    function checkAndHideContainer() {
        // Verifica se o conteúdo do container está vazio ou contém apenas espaços em branco
        if (!container.textContent.trim()) {
            container.style.display = 'none';
        } else {
            container.style.display = 'block'; // Garante que o container fique visível se houver conteúdo
        }
    }

    // Verifica inicialmente quando a página é carregada
    checkAndHideContainer();

    // Caso o conteúdo seja atualizado dinamicamente, pode-se usar um MutationObserver
    const observer = new MutationObserver(() => {
        checkAndHideContainer();
    });

    // Observa mudanças no conteúdo do container
    observer.observe(container, { childList: true, subtree: true });
});


</script>

</div>