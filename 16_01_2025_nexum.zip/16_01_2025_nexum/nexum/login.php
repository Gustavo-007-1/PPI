<?php 
    session_start();
    if(empty($_POST) or (empty($_POST["email"]) or (empty($_POST["senha"])))){
        echo "<script>location.href='index.php';</script>";
    }

    include("config.php");

    $email = $_POST["email"];
    $senha = $_POST["senha"];

    # faz a consulta e seleção no bd
    $sql = "SELECT * FROM usuario
            WHERE email = '{$email}' LIMIT 1";

    $res = $conexao->query($sql) or die($conexao->error);
    $row = $res->fetch_object();
    $quantidade = $res->num_rows;

    if(password_verify($senha, $row->senha)){
        if($quantidade>0){
            $_SESSION["nome"] = $nome;
            $_SESSION["email"] = $email;
            $_SESSION["categoria"] = $row->categoria;
            $_SESSION["id_usuario"] = $row->id_usuario;
    
            echo "<script>location.href='pagina_principal.php';</script>";
    
        }
    }

    else{
        echo "<script>alert('Usuario e/ou senha incorretos(s)');</script>";
        echo "<script>location.href='index.php';</script>";
    }
?>